package com.example

import com.example.engine.TimelineInterpolator
import com.example.model.*
import com.example.parser.XmlProjectParser
import com.example.parser.XmlProjectSerializer
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class MotionStudioUnitTest {

    @Test
    fun testKeyframeCurveEvaluation() {
        val linear = KeyframeCurve.LINEAR
        assertEquals(0.0f, linear.evaluate(0f), 0.001f)
        assertEquals(0.5f, linear.evaluate(0.5f), 0.05f)
        assertEquals(1.0f, linear.evaluate(1.0f), 0.001f)

        val easeIn = KeyframeCurve.EASE_IN
        assertTrue("Ease in should start slower than linear", easeIn.evaluate(0.3f) < linear.evaluate(0.3f))
    }

    @Test
    fun testTimelineInterpolator() {
        val layer = MotionLayer(
            id = "layer1",
            name = "Test Box",
            type = LayerType.SHAPE,
            startTimeMs = 0L,
            endTimeMs = 2000L,
            transform = LayerTransform(positionX = 100f, positionY = 100f),
            positionKeyframes = listOf(
                Keyframe(0L, Point2D(100f, 100f), KeyframeCurve.LINEAR),
                Keyframe(2000L, Point2D(300f, 500f), KeyframeCurve.LINEAR)
            )
        )

        // At t=0
        val state0 = TimelineInterpolator.evaluate(layer, 0L)
        assertEquals(100f, state0.positionX, 0.01f)
        assertEquals(100f, state0.positionY, 0.01f)
        assertTrue(state0.isVisibleAtTime)

        // At midpoint t=1000
        val stateMid = TimelineInterpolator.evaluate(layer, 1000L)
        assertEquals(200f, stateMid.positionX, 5.0f)
        assertEquals(300f, stateMid.positionY, 5.0f)

        // Out of bounds t=3000
        val stateAfter = TimelineInterpolator.evaluate(layer, 3000L)
        assertFalse(stateAfter.isVisibleAtTime)
    }

    @Test
    fun testXmlParserAndPreservation() {
        val sampleXml = """
            <scene name="Test XML" width="1080" height="1920" fps="30" totalTime="4000" bgcolor="#0D0F17">
              <shape name="Neon Circle" type="circle" startTime="0" endTime="3000" width="300" height="300">
                <transform>
                  <property name="position">
                    <keyframe time="0" value="540,960"/>
                    <keyframe time="2000" value="540,500"/>
                  </property>
                </transform>
                <fill color="#FF00E5FF"/>
              </shape>
              <customUnsupportedShader parameter="blur3d" value="20"/>
            </scene>
        """.trimIndent()

        val parseResult = XmlProjectParser.parse(sampleXml)
        val project = parseResult.project

        assertEquals("Test XML", project.name)
        assertEquals(1080, project.width)
        assertEquals(1920, project.height)
        assertEquals(4000L, project.durationMs)
        assertEquals(1, project.layers.size)

        val layer = project.layers.first()
        assertEquals("Neon Circle", layer.name)
        assertEquals(ShapeType.CIRCLE, layer.shapeType)
        assertEquals(2, layer.positionKeyframes.size)

        // Check that unsupported node was preserved rather than discarded
        assertTrue("Unsupported node should be preserved", project.unsupportedNodes.any { it.tagName.equals("customUnsupportedShader", ignoreCase = true) })

        // Check XML serialization
        val serializedXml = XmlProjectSerializer.serialize(project)
        assertTrue(serializedXml.contains("<scene"))
        assertTrue(serializedXml.contains("Neon Circle"))
        assertTrue(serializedXml.contains("customUnsupportedShader", ignoreCase = true))
    }
}
