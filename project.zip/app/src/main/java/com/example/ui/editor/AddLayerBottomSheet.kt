package com.example.ui.editor

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.theme.*

private data class LayerTemplateItem(
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val color: Color,
    val actionType: String,
    val shapeType: ShapeType? = null
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddLayerBottomSheet(
    project: Project,
    currentTimeMs: Long,
    onAddLayer: (MotionLayer) -> Unit,
    onDismiss: () -> Unit
) {
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            val layer = MotionLayer(
                name = "Image Layer",
                type = LayerType.IMAGE,
                startTimeMs = currentTimeMs,
                endTimeMs = (currentTimeMs + 4000L).coerceAtMost(project.durationMs),
                mediaUri = uri.toString(),
                width = 600f,
                height = 600f,
                transform = LayerTransform(positionX = project.width / 2f, positionY = project.height / 2f)
            )
            onAddLayer(layer)
            onDismiss()
        }
    }

    val templates = listOf(
        LayerTemplateItem("Rectangle", "Box / card element", Icons.Default.CropSquare, StudioNeonCyan, "SHAPE", ShapeType.RECTANGLE),
        LayerTemplateItem("Rounded Card", "Smooth rounded rect", Icons.Default.RoundedCorner, StudioElectricPurple, "SHAPE", ShapeType.ROUNDED_RECT),
        LayerTemplateItem("Circle / Aura", "Radial pulse shape", Icons.Default.Circle, StudioMintGreen, "SHAPE", ShapeType.CIRCLE),
        LayerTemplateItem("Motion Star", "5-point burst star", Icons.Default.Star, TimelineKeyframeNode, "SHAPE", ShapeType.STAR),
        LayerTemplateItem("Triangle", "Geometric accent", Icons.Default.ChangeHistory, StudioCoralRed, "SHAPE", ShapeType.TRIANGLE),
        LayerTemplateItem("Heart Shape", "Vector heart icon", Icons.Default.Favorite, TimelineClipText, "SHAPE", ShapeType.HEART),
        LayerTemplateItem("Kinetic Text", "Editable animated typography", Icons.Default.TextFields, StudioNeonCyan, "TEXT"),
        LayerTemplateItem("Device Image", "Photo from phone gallery", Icons.Default.Image, StudioMintGreen, "IMAGE"),
        LayerTemplateItem("Video Clip", "Motion video layer", Icons.Default.Movie, TimelineClipVideo, "VIDEO"),
        LayerTemplateItem("Audio Track", "Background music or beat", Icons.Default.Audiotrack, TimelineClipAudio, "AUDIO")
    )

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = StudioSurfaceDark,
        dragHandle = { BottomSheetDefaults.DragHandle(color = StudioTextMuted) },
        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp)
        ) {
            Text(
                text = "Add New Layer",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = StudioTextPrimary
            )
            Text(
                text = "Select an element to add to your composition timeline",
                style = MaterialTheme.typography.bodySmall,
                color = StudioTextSecondary
            )

            Spacer(modifier = Modifier.height(16.dp))

            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 32.dp)
            ) {
                items(templates) { item ->
                    Surface(
                        color = StudioSurfaceElevated,
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, StudioSurfaceBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable {
                                when (item.actionType) {
                                    "SHAPE" -> {
                                        val newLayer = MotionLayer(
                                            name = item.title,
                                            type = LayerType.SHAPE,
                                            shapeType = item.shapeType ?: ShapeType.RECTANGLE,
                                            startTimeMs = currentTimeMs,
                                            endTimeMs = (currentTimeMs + 3500L).coerceAtMost(project.durationMs),
                                            width = if (item.shapeType == ShapeType.CIRCLE) 400f else 460f,
                                            height = if (item.shapeType == ShapeType.CIRCLE) 400f else 320f,
                                            fillColor = item.color.value.toLong(),
                                            transform = LayerTransform(positionX = project.width / 2f, positionY = project.height / 2f)
                                        )
                                        onAddLayer(newLayer)
                                        onDismiss()
                                    }
                                    "TEXT" -> {
                                        val newLayer = MotionLayer(
                                            name = "Kinetic Title",
                                            type = LayerType.TEXT,
                                            text = "MOTION GRAPHICS",
                                            textSize = 68f,
                                            textColor = 0xFFFFFFFF,
                                            startTimeMs = currentTimeMs,
                                            endTimeMs = (currentTimeMs + 4000L).coerceAtMost(project.durationMs),
                                            transform = LayerTransform(positionX = project.width / 2f, positionY = project.height / 2f),
                                            effects = listOf(LayerEffect(type = "GLOW", color = 0xFF00E5FF))
                                        )
                                        onAddLayer(newLayer)
                                        onDismiss()
                                    }
                                    "IMAGE" -> {
                                        photoPickerLauncher.launch(
                                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                        )
                                    }
                                    "VIDEO" -> {
                                        val newLayer = MotionLayer(
                                            name = "Neon Synth Video",
                                            type = LayerType.VIDEO,
                                            startTimeMs = currentTimeMs,
                                            endTimeMs = (currentTimeMs + 4500L).coerceAtMost(project.durationMs),
                                            width = 640f,
                                            height = 360f,
                                            transform = LayerTransform(positionX = project.width / 2f, positionY = project.height / 2f)
                                        )
                                        onAddLayer(newLayer)
                                        onDismiss()
                                    }
                                    "AUDIO" -> {
                                        val newLayer = MotionLayer(
                                            name = "Audio Beat Track",
                                            type = LayerType.AUDIO,
                                            startTimeMs = 0L,
                                            endTimeMs = project.durationMs,
                                            audioVolume = 1.0f
                                        )
                                        onAddLayer(newLayer)
                                        onDismiss()
                                    }
                                }
                            }
                            .testTag("add_template_${item.title.lowercase().replace(" ", "_")}")
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .background(item.color.copy(alpha = 0.15f), RoundedCornerShape(8.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(item.icon, contentDescription = null, tint = item.color, modifier = Modifier.size(20.dp))
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(item.title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = StudioTextPrimary)
                                Text(item.subtitle, fontSize = 10.sp, color = StudioTextSecondary, maxLines = 1)
                            }
                        }
                    }
                }
            }
        }
    }
}
