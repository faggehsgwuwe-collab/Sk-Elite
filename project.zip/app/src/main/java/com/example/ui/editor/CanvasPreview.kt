package com.example.ui.editor

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CropFree
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.CanvasFrameRenderer
import com.example.engine.EvaluatedLayerState
import com.example.engine.TimelineInterpolator
import com.example.model.MotionLayer
import com.example.model.Project
import com.example.ui.theme.*

@Composable
fun CanvasPreview(
    project: Project,
    currentTimeMs: Long,
    selectedLayerId: String?,
    onSelectLayer: (String?) -> Unit,
    onUpdateLayerTransform: (layerId: String, newPosX: Float, newPosY: Float) -> Unit,
    modifier: Modifier = Modifier
) {
    var canvasScale by remember { mutableFloatStateOf(1f) }
    var canvasOffset by remember { mutableStateOf(Offset.Zero) }

    val transformState = rememberTransformableState { zoomChange, panChange, _ ->
        canvasScale = (canvasScale * zoomChange).coerceIn(0.5f, 3.5f)
        canvasOffset += panChange
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(StudioDarkBackground)
            .clip(RoundedCornerShape(12.dp))
            .border(1.dp, StudioSurfaceBorder, RoundedCornerShape(12.dp))
            .transformable(state = transformState),
        contentAlignment = Alignment.Center
    ) {
        // Project aspect ratio viewport container
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            val containerWidth = maxWidth.value
            val containerHeight = maxHeight.value

            val projectAspect = project.width.toFloat() / project.height.toFloat()
            val containerAspect = containerWidth / containerHeight

            val (viewportWidthDp, viewportHeightDp) = if (projectAspect > containerAspect) {
                containerWidth to (containerWidth / projectAspect)
            } else {
                (containerHeight * projectAspect) to containerHeight
            }

            val scaleToViewport = viewportWidthDp / project.width.toFloat()

            // Viewport Canvas
            Box(
                modifier = Modifier
                    .size(viewportWidthDp.dp, viewportHeightDp.dp)
                    .shadow(16.dp, RoundedCornerShape(4.dp))
                    .border(1.5.dp, StudioSurfaceBorder.copy(alpha = 0.8f))
            ) {
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("preview_canvas")
                        .pointerInput(project, currentTimeMs, selectedLayerId) {
                            detectTapGestures { tapOffset ->
                                // Convert tapOffset into project coordinates
                                val projX = tapOffset.x / scaleToViewport
                                val projY = tapOffset.y / scaleToViewport

                                // Find topmost active layer clicked
                                var clickedLayerId: String? = null
                                for (layer in project.layers.asReversed()) {
                                    val state = TimelineInterpolator.evaluate(layer, currentTimeMs)
                                    if (!state.isVisibleAtTime) continue

                                    val halfW = (layer.width * state.scaleX) / 2f
                                    val halfH = (layer.height * state.scaleY) / 2f
                                    if (projX in (state.positionX - halfW)..(state.positionX + halfW) &&
                                        projY in (state.positionY - halfH)..(state.positionY + halfH)
                                    ) {
                                        clickedLayerId = layer.id
                                        break
                                    }
                                }
                                onSelectLayer(clickedLayerId)
                            }
                        }
                        .pointerInput(selectedLayerId) {
                            if (selectedLayerId != null) {
                                detectDragGestures { change, dragAmount ->
                                    change.consume()
                                    val selected = project.layers.firstOrNull { it.id == selectedLayerId }
                                    if (selected != null && !selected.isLocked) {
                                        val evaluated = TimelineInterpolator.evaluate(selected, currentTimeMs)
                                        val newX = evaluated.positionX + (dragAmount.x / scaleToViewport)
                                        val newY = evaluated.positionY + (dragAmount.y / scaleToViewport)
                                        onUpdateLayerTransform(selected.id, newX, newY)
                                    }
                                }
                            }
                        }
                ) {
                    val nativeCanvas = drawContext.canvas.nativeCanvas

                    // Render all layers
                    CanvasFrameRenderer.renderFrame(
                        canvas = nativeCanvas,
                        project = project,
                        timeMs = currentTimeMs,
                        renderWidth = size.width.toInt(),
                        renderHeight = size.height.toInt()
                    )

                    // Draw selection bounding box for currently selected layer
                    val selectedLayer = project.layers.firstOrNull { it.id == selectedLayerId }
                    if (selectedLayer != null) {
                        val state = TimelineInterpolator.evaluate(selectedLayer, currentTimeMs)
                        if (state.isVisibleAtTime) {
                            val centerX = state.positionX * scaleToViewport
                            val centerY = state.positionY * scaleToViewport
                            val halfW = (selectedLayer.width * state.scaleX * scaleToViewport) / 2f
                            val halfH = (selectedLayer.height * state.scaleY * scaleToViewport) / 2f

                            // Selection rect
                            drawRect(
                                color = StudioNeonCyan,
                                topLeft = Offset(centerX - halfW, centerY - halfH),
                                size = Size(halfW * 2, halfH * 2),
                                style = Stroke(width = 2.dp.toPx())
                            )

                            // Corner handles
                            val handleRadius = 5.dp.toPx()
                            val corners = listOf(
                                Offset(centerX - halfW, centerY - halfH),
                                Offset(centerX + halfW, centerY - halfH),
                                Offset(centerX - halfW, centerY + halfH),
                                Offset(centerX + halfW, centerY + halfH)
                            )
                            for (c in corners) {
                                drawCircle(
                                    color = Color.White,
                                    radius = handleRadius,
                                    center = c
                                )
                                drawCircle(
                                    color = StudioNeonCyan,
                                    radius = handleRadius,
                                    center = c,
                                    style = Stroke(width = 1.5.dp.toPx())
                                )
                            }
                        }
                    }
                }
            }
        }

        // Viewport overlay controls (Reset zoom & ratio badge)
        Row(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                color = StudioSurfaceElevated.copy(alpha = 0.85f),
                shape = RoundedCornerShape(6.dp)
            ) {
                Text(
                    text = "${project.aspectRatio.widthRatio}:${project.aspectRatio.heightRatio} • ${project.fps} FPS",
                    style = MaterialTheme.typography.labelSmall,
                    color = StudioTextSecondary,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
            Spacer(modifier = Modifier.width(6.dp))
            IconButton(
                onClick = {
                    canvasScale = 1f
                    canvasOffset = Offset.Zero
                },
                modifier = Modifier
                    .size(32.dp)
                    .background(StudioSurfaceElevated.copy(alpha = 0.85f), RoundedCornerShape(6.dp))
                    .testTag("reset_zoom_button")
            ) {
                Icon(
                    imageVector = Icons.Default.CropFree,
                    contentDescription = "Fit to Screen",
                    tint = StudioNeonCyan,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}
