package com.example.ui.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.theme.*

@Composable
fun PropertyInspector(
    layer: MotionLayer,
    currentTimeMs: Long,
    onUpdateLayer: (MotionLayer) -> Unit,
    onOpenCurveEditor: (propertyName: String, initialCurve: KeyframeCurve) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Transform", "Style & Content", "Effects")

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(StudioSurfaceDark)
            .border(1.dp, StudioSurfaceBorder)
    ) {
        // Top Bar: Layer Name + Close
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    color = StudioNeonCyan.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = layer.type.name,
                        style = MaterialTheme.typography.labelSmall,
                        color = StudioNeonCyan,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = layer.name,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = StudioTextPrimary
                )
            }
            IconButton(onClick = onClose, modifier = Modifier.size(32.dp)) {
                Icon(Icons.Default.Close, contentDescription = "Close Inspector", tint = StudioTextSecondary)
            }
        }

        // Tab Row
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = StudioSurfaceElevated,
            contentColor = StudioNeonCyan,
            divider = {}
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    text = {
                        Text(
                            text = title,
                            fontSize = 12.sp,
                            fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                )
            }
        }

        // Tab Content
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            when (selectedTab) {
                0 -> TransformTab(
                    layer = layer,
                    currentTimeMs = currentTimeMs,
                    onUpdateLayer = onUpdateLayer,
                    onOpenCurveEditor = onOpenCurveEditor
                )
                1 -> StyleTab(layer = layer, onUpdateLayer = onUpdateLayer)
                2 -> EffectsTab(layer = layer, onUpdateLayer = onUpdateLayer)
            }
        }
    }
}

@Composable
private fun TransformTab(
    layer: MotionLayer,
    currentTimeMs: Long,
    onUpdateLayer: (MotionLayer) -> Unit,
    onOpenCurveEditor: (propertyName: String, initialCurve: KeyframeCurve) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        // Keyframe Toolbar (Alight Motion workflow)
        Surface(
            color = StudioSurfaceElevated,
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Animation,
                        contentDescription = null,
                        tint = TimelineKeyframeNode,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Keyframe Editor", style = MaterialTheme.typography.labelMedium, color = StudioTextPrimary)
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    // Check if current time has keyframe on position
                    val hasPosKeyframe = layer.positionKeyframes.any { it.timeMs == currentTimeMs }

                    Button(
                        onClick = {
                            val newPosKfs = layer.positionKeyframes.toMutableList()
                            val newScaleKfs = layer.scaleKeyframes.toMutableList()
                            val newRotKfs = layer.rotationKeyframes.toMutableList()
                            val newOpKfs = layer.opacityKeyframes.toMutableList()

                            if (hasPosKeyframe) {
                                // Remove keyframe at current time
                                newPosKfs.removeAll { it.timeMs == currentTimeMs }
                                newScaleKfs.removeAll { it.timeMs == currentTimeMs }
                                newRotKfs.removeAll { it.timeMs == currentTimeMs }
                                newOpKfs.removeAll { it.timeMs == currentTimeMs }
                            } else {
                                // Add keyframe at current time
                                newPosKfs.add(Keyframe(currentTimeMs, Point2D(layer.transform.positionX, layer.transform.positionY)))
                                newScaleKfs.add(Keyframe(currentTimeMs, Point2D(layer.transform.scaleX, layer.transform.scaleY)))
                                newRotKfs.add(Keyframe(currentTimeMs, layer.transform.rotation))
                                newOpKfs.add(Keyframe(currentTimeMs, layer.transform.opacity))
                            }

                            onUpdateLayer(
                                layer.copy(
                                    positionKeyframes = newPosKfs.sortedBy { it.timeMs },
                                    scaleKeyframes = newScaleKfs.sortedBy { it.timeMs },
                                    rotationKeyframes = newRotKfs.sortedBy { it.timeMs },
                                    opacityKeyframes = newOpKfs.sortedBy { it.timeMs }
                                )
                            )
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (hasPosKeyframe) StudioCoralRed else StudioNeonCyan
                        ),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        modifier = Modifier.testTag("toggle_keyframe_button")
                    ) {
                        Icon(
                            imageVector = if (hasPosKeyframe) Icons.Default.Remove else Icons.Default.Add,
                            contentDescription = null,
                            tint = StudioDarkBackground,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (hasPosKeyframe) "Remove KF" else "+ Keyframe",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = StudioDarkBackground
                        )
                    }

                    // Curve Editor Graph Button
                    IconButton(
                        onClick = {
                            val curve = layer.positionKeyframes.firstOrNull()?.curve ?: KeyframeCurve.EASE_IN_OUT
                            onOpenCurveEditor("Transform", curve)
                        },
                        modifier = Modifier.size(32.dp).testTag("open_curve_editor_btn")
                    ) {
                        Icon(Icons.Default.Timeline, contentDescription = "Curve Graph", tint = StudioNeonCyan)
                    }
                }
            }
        }

        // Position X & Y
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Position X: ${layer.transform.positionX.toInt()} px", style = MaterialTheme.typography.bodySmall, color = StudioTextSecondary)
                Slider(
                    value = layer.transform.positionX,
                    onValueChange = { newX ->
                        val updatedTransform = layer.transform.copy(positionX = newX)
                        val updatedKfs = if (layer.positionKeyframes.any { it.timeMs == currentTimeMs }) {
                            layer.positionKeyframes.map { if (it.timeMs == currentTimeMs) it.copy(value = Point2D(newX, it.value.y)) else it }
                        } else layer.positionKeyframes
                        onUpdateLayer(layer.copy(transform = updatedTransform, positionKeyframes = updatedKfs))
                    },
                    valueRange = -200f..1280f,
                    colors = SliderDefaults.colors(thumbColor = StudioNeonCyan, activeTrackColor = StudioNeonCyan)
                )
            }
            Column(modifier = Modifier.weight(1f)) {
                Text("Position Y: ${layer.transform.positionY.toInt()} px", style = MaterialTheme.typography.bodySmall, color = StudioTextSecondary)
                Slider(
                    value = layer.transform.positionY,
                    onValueChange = { newY ->
                        val updatedTransform = layer.transform.copy(positionY = newY)
                        val updatedKfs = if (layer.positionKeyframes.any { it.timeMs == currentTimeMs }) {
                            layer.positionKeyframes.map { if (it.timeMs == currentTimeMs) it.copy(value = Point2D(it.value.x, newY)) else it }
                        } else layer.positionKeyframes
                        onUpdateLayer(layer.copy(transform = updatedTransform, positionKeyframes = updatedKfs))
                    },
                    valueRange = -200f..2120f,
                    colors = SliderDefaults.colors(thumbColor = StudioNeonCyan, activeTrackColor = StudioNeonCyan)
                )
            }
        }

        // Scale
        Column {
            Text("Scale: ${String.format("%.2fx", layer.transform.scaleX)}", style = MaterialTheme.typography.bodySmall, color = StudioTextSecondary)
            Slider(
                value = layer.transform.scaleX,
                onValueChange = { newScale ->
                    val updatedTransform = layer.transform.copy(scaleX = newScale, scaleY = newScale)
                    val updatedKfs = if (layer.scaleKeyframes.any { it.timeMs == currentTimeMs }) {
                        layer.scaleKeyframes.map { if (it.timeMs == currentTimeMs) it.copy(value = Point2D(newScale, newScale)) else it }
                    } else layer.scaleKeyframes
                    onUpdateLayer(layer.copy(transform = updatedTransform, scaleKeyframes = updatedKfs))
                },
                valueRange = 0.1f..4.0f,
                colors = SliderDefaults.colors(thumbColor = StudioElectricPurple, activeTrackColor = StudioElectricPurple)
            )
        }

        // Rotation
        Column {
            Text("Rotation: ${layer.transform.rotation.toInt()}°", style = MaterialTheme.typography.bodySmall, color = StudioTextSecondary)
            Slider(
                value = layer.transform.rotation,
                onValueChange = { newRot ->
                    val updatedTransform = layer.transform.copy(rotation = newRot)
                    val updatedKfs = if (layer.rotationKeyframes.any { it.timeMs == currentTimeMs }) {
                        layer.rotationKeyframes.map { if (it.timeMs == currentTimeMs) it.copy(value = newRot) else it }
                    } else layer.rotationKeyframes
                    onUpdateLayer(layer.copy(transform = updatedTransform, rotationKeyframes = updatedKfs))
                },
                valueRange = -180f..180f,
                colors = SliderDefaults.colors(thumbColor = StudioMintGreen, activeTrackColor = StudioMintGreen)
            )
        }

        // Opacity
        Column {
            Text("Opacity: ${(layer.transform.opacity * 100).toInt()}%", style = MaterialTheme.typography.bodySmall, color = StudioTextSecondary)
            Slider(
                value = layer.transform.opacity,
                onValueChange = { newOp ->
                    val updatedTransform = layer.transform.copy(opacity = newOp)
                    val updatedKfs = if (layer.opacityKeyframes.any { it.timeMs == currentTimeMs }) {
                        layer.opacityKeyframes.map { if (it.timeMs == currentTimeMs) it.copy(value = newOp) else it }
                    } else layer.opacityKeyframes
                    onUpdateLayer(layer.copy(transform = updatedTransform, opacityKeyframes = updatedKfs))
                },
                valueRange = 0f..1f,
                colors = SliderDefaults.colors(thumbColor = StudioCoralRed, activeTrackColor = StudioCoralRed)
            )
        }
    }
}

@Composable
private fun StyleTab(
    layer: MotionLayer,
    onUpdateLayer: (MotionLayer) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        when (layer.type) {
            LayerType.SHAPE -> {
                // Shape Type Picker
                Text("Shape Geometry", style = MaterialTheme.typography.titleSmall, color = StudioTextPrimary)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(ShapeType.values()) { st ->
                        val isSelected = layer.shapeType == st
                        FilterChip(
                            selected = isSelected,
                            onClick = { onUpdateLayer(layer.copy(shapeType = st)) },
                            label = { Text(st.name.replace("_", " "), fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = StudioNeonCyan,
                                selectedLabelColor = StudioDarkBackground,
                                containerColor = StudioSurfaceElevated,
                                labelColor = StudioTextPrimary
                            )
                        )
                    }
                }

                // Width & Height
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Width: ${layer.width.toInt()} dp", style = MaterialTheme.typography.bodySmall, color = StudioTextSecondary)
                        Slider(
                            value = layer.width,
                            onValueChange = { onUpdateLayer(layer.copy(width = it)) },
                            valueRange = 50f..1000f,
                            colors = SliderDefaults.colors(thumbColor = StudioNeonCyan, activeTrackColor = StudioNeonCyan)
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Height: ${layer.height.toInt()} dp", style = MaterialTheme.typography.bodySmall, color = StudioTextSecondary)
                        Slider(
                            value = layer.height,
                            onValueChange = { onUpdateLayer(layer.copy(height = it)) },
                            valueRange = 50f..1000f,
                            colors = SliderDefaults.colors(thumbColor = StudioNeonCyan, activeTrackColor = StudioNeonCyan)
                        )
                    }
                }

                // Fill Color Palette
                Text("Fill Color", style = MaterialTheme.typography.titleSmall, color = StudioTextPrimary)
                ColorPaletteRow(
                    selectedColor = layer.fillColor,
                    onSelectColor = { onUpdateLayer(layer.copy(fillColor = it)) }
                )

                // Corner Radius (if rounded rect)
                if (layer.shapeType == ShapeType.ROUNDED_RECT || layer.shapeType == ShapeType.RECTANGLE) {
                    Column {
                        Text("Corner Radius: ${layer.cornerRadius.toInt()} dp", style = MaterialTheme.typography.bodySmall, color = StudioTextSecondary)
                        Slider(
                            value = layer.cornerRadius,
                            onValueChange = { onUpdateLayer(layer.copy(cornerRadius = it)) },
                            valueRange = 0f..150f
                        )
                    }
                }

                // Stroke Width
                Column {
                    Text("Stroke Width: ${layer.strokeWidth.toInt()} dp", style = MaterialTheme.typography.bodySmall, color = StudioTextSecondary)
                    Slider(
                        value = layer.strokeWidth,
                        onValueChange = { onUpdateLayer(layer.copy(strokeWidth = it)) },
                        valueRange = 0f..30f
                    )
                }
            }

            LayerType.TEXT -> {
                Text("Text Content", style = MaterialTheme.typography.titleSmall, color = StudioTextPrimary)
                OutlinedTextField(
                    value = layer.text,
                    onValueChange = { onUpdateLayer(layer.copy(text = it)) },
                    modifier = Modifier.fillMaxWidth().testTag("text_layer_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = StudioNeonCyan,
                        unfocusedBorderColor = StudioSurfaceBorder,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    )
                )

                Column {
                    Text("Font Size: ${layer.textSize.toInt()} sp", style = MaterialTheme.typography.bodySmall, color = StudioTextSecondary)
                    Slider(
                        value = layer.textSize,
                        onValueChange = { onUpdateLayer(layer.copy(textSize = it)) },
                        valueRange = 16f..140f,
                        colors = SliderDefaults.colors(thumbColor = StudioNeonCyan, activeTrackColor = StudioNeonCyan)
                    )
                }

                Text("Text Color", style = MaterialTheme.typography.titleSmall, color = StudioTextPrimary)
                ColorPaletteRow(
                    selectedColor = layer.textColor,
                    onSelectColor = { onUpdateLayer(layer.copy(textColor = it)) }
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Bold Typography", color = StudioTextSecondary, fontSize = 14.sp)
                    Switch(
                        checked = layer.isBold,
                        onCheckedChange = { onUpdateLayer(layer.copy(isBold = it)) },
                        colors = SwitchDefaults.colors(checkedThumbColor = StudioNeonCyan)
                    )
                }
            }

            LayerType.IMAGE, LayerType.VIDEO -> {
                Text("Media Source", style = MaterialTheme.typography.titleSmall, color = StudioTextPrimary)
                Text(
                    text = layer.mediaUri ?: "Default studio asset",
                    style = MaterialTheme.typography.bodySmall,
                    color = StudioTextSecondary
                )
            }

            LayerType.AUDIO -> {
                Text("Audio Volume: ${(layer.audioVolume * 100).toInt()}%", style = MaterialTheme.typography.titleSmall, color = StudioTextPrimary)
                Slider(
                    value = layer.audioVolume,
                    onValueChange = { onUpdateLayer(layer.copy(audioVolume = it)) },
                    valueRange = 0f..1f,
                    colors = SliderDefaults.colors(thumbColor = StudioElectricPurple, activeTrackColor = StudioElectricPurple)
                )
            }
        }
    }
}

@Composable
private fun EffectsTab(
    layer: MotionLayer,
    onUpdateLayer: (MotionLayer) -> Unit
) {
    val glowEffect = layer.effects.firstOrNull { it.type == "GLOW" }
    val isGlowEnabled = glowEffect != null && glowEffect.isEnabled

    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        // Glow Effect Card
        Surface(
            color = StudioSurfaceElevated,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.BlurOn, contentDescription = null, tint = StudioNeonCyan)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Neon Glow Aura", fontWeight = FontWeight.Bold, color = StudioTextPrimary)
                    }
                    Switch(
                        checked = isGlowEnabled,
                        onCheckedChange = { enabled ->
                            val newEffects = layer.effects.filter { it.type != "GLOW" }.toMutableList()
                            if (enabled) {
                                newEffects.add(LayerEffect(type = "GLOW", isEnabled = true, color = 0xFF00E5FF))
                            }
                            onUpdateLayer(layer.copy(effects = newEffects))
                        },
                        colors = SwitchDefaults.colors(checkedThumbColor = StudioNeonCyan)
                    )
                }

                if (isGlowEnabled) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("Glow Color", style = MaterialTheme.typography.labelSmall, color = StudioTextSecondary)
                    ColorPaletteRow(
                        selectedColor = glowEffect?.color ?: 0xFF00E5FF,
                        onSelectColor = { c ->
                            val updated = layer.effects.map { if (it.type == "GLOW") it.copy(color = c) else it }
                            onUpdateLayer(layer.copy(effects = updated))
                        }
                    )
                }
            }
        }

        // Shadow Card
        val shadowEffect = layer.effects.firstOrNull { it.type == "SHADOW" }
        val isShadowEnabled = shadowEffect != null && shadowEffect.isEnabled
        Surface(
            color = StudioSurfaceElevated,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.WbTwilight, contentDescription = null, tint = StudioElectricPurple)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Drop Shadow", fontWeight = FontWeight.Bold, color = StudioTextPrimary)
                }
                Switch(
                    checked = isShadowEnabled,
                    onCheckedChange = { enabled ->
                        val newEffects = layer.effects.filter { it.type != "SHADOW" }.toMutableList()
                        if (enabled) {
                            newEffects.add(LayerEffect(type = "SHADOW", isEnabled = true, color = 0xFF000000))
                        }
                        onUpdateLayer(layer.copy(effects = newEffects))
                    },
                    colors = SwitchDefaults.colors(checkedThumbColor = StudioElectricPurple)
                )
            }
        }

        // Preserved XML Nodes for this layer
        if (layer.customXmlChildren.isNotEmpty() || layer.customXmlAttributes.isNotEmpty()) {
            Surface(
                color = StudioDarkBackground,
                shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, StudioAmberWarning.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = StudioAmberWarning, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Preserved Alight Motion Properties",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = StudioAmberWarning
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "${layer.customXmlAttributes.size} custom attributes, ${layer.customXmlChildren.size} child tags preserved safely.",
                        style = MaterialTheme.typography.bodySmall,
                        color = StudioTextSecondary
                    )
                }
            }
        }
    }
}

@Composable
fun ColorPaletteRow(
    selectedColor: Long,
    onSelectColor: (Long) -> Unit
) {
    val palette = listOf(
        0xFF00E5FF, // Neon Cyan
        0xFF7C4DFF, // Electric Purple
        0xFF00E676, // Mint Green
        0xFFFFEA00, // Bright Yellow
        0xFFFF4081, // Hot Pink
        0xFFFF1744, // Crimson Red
        0xFFFFFFFF, // Pure White
        0xFF1A1E2E  // Dark Slate
    )

    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        items(palette) { colorLong ->
            val isSelected = selectedColor == colorLong
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color(colorLong))
                    .border(
                        width = if (isSelected) 3.dp else 1.dp,
                        color = if (isSelected) Color.White else StudioSurfaceBorder,
                        shape = CircleShape
                    )
                    .clickable { onSelectColor(colorLong) }
            )
        }
    }
}
