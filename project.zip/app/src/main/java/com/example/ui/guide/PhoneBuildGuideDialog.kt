package com.example.ui.guide

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.*

@Composable
fun PhoneBuildGuideDialog(
    onDismiss: () -> Unit
) {
    val context = LocalContext.current

    val termuxScript = """
# 1. Install free Termux from F-Droid
# 2. Update packages and install OpenJDK & Gradle
pkg update && pkg upgrade -y
pkg install openjdk-17 gradle git wget -y

# 3. Navigate to your project folder
cd ~/storage/shared/Download/SK_MUZAMMEL_Motion_Studio

# 4. Build APK using free Gradle
gradle assembleDebug

# Output APK location:
# app/build/outputs/apk/debug/app-debug.apk
    """.trimIndent()

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = StudioSurfaceDark,
            border = androidx.compose.foundation.BorderStroke(1.dp, StudioSurfaceBorder),
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(StudioNeonCyan.copy(alpha = 0.15f), RoundedCornerShape(8.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.PhoneAndroid, contentDescription = null, tint = StudioNeonCyan, modifier = Modifier.size(20.dp))
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("Build APK on Android Phone", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = StudioTextPrimary)
                            Text("100% Free Tools Guide", style = MaterialTheme.typography.bodySmall, color = StudioNeonCyan)
                        }
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = StudioTextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f, fill = false)
                        .heightIn(max = 380.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item {
                        Surface(
                            color = StudioSurfaceElevated,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text("Option 1: AndroidIDE (Easiest GUI)", fontWeight = FontWeight.Bold, color = StudioMintGreen, fontSize = 14.sp)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    "1. Download 'AndroidIDE' (free open-source app from F-Droid or GitHub).\n" +
                                    "2. Open this project folder inside AndroidIDE.\n" +
                                    "3. Tap the green 'Build & Run' icon. It compiles the APK locally on your phone without a PC!",
                                    fontSize = 12.sp,
                                    color = StudioTextSecondary,
                                    lineHeight = 18.sp
                                )
                            }
                        }
                    }

                    item {
                        Surface(
                            color = StudioSurfaceElevated,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Option 2: Termux CLI (Fast)", fontWeight = FontWeight.Bold, color = StudioNeonCyan, fontSize = 14.sp)
                                    IconButton(
                                        onClick = {
                                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                            val clip = ClipData.newPlainText("Termux Commands", termuxScript)
                                            clipboard.setPrimaryClip(clip)
                                            Toast.makeText(context, "Commands copied to clipboard!", Toast.LENGTH_SHORT).show()
                                        },
                                        modifier = Modifier.size(28.dp).testTag("copy_termux_commands_btn")
                                    ) {
                                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = StudioNeonCyan, modifier = Modifier.size(16.dp))
                                    }
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = termuxScript,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 10.sp,
                                    color = StudioTextPrimary,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(StudioDarkBackground, RoundedCornerShape(6.dp))
                                        .padding(8.dp)
                                )
                            }
                        }
                    }

                    item {
                        Surface(
                            color = StudioSurfaceElevated,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text("Option 3: AI Studio Direct APK Export", fontWeight = FontWeight.Bold, color = StudioElectricPurple, fontSize = 14.sp)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    "From the AI Studio top bar settings menu, select 'Download APK' or 'Download ZIP' to install directly onto any Android phone or tablet.",
                                    fontSize = 12.sp,
                                    color = StudioTextSecondary,
                                    lineHeight = 18.sp
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = StudioNeonCyan),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Got It", color = StudioDarkBackground, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
