package com.example.ui.editor

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.KeyframeCurve
import com.example.ui.theme.*

@Composable
fun CurveEditorDialog(
    initialCurve: KeyframeCurve,
    propertyName: String,
    onDismiss: () -> Unit,
    onApplyCurve: (KeyframeCurve) -> Unit
) {
    var x1 by remember { mutableFloatStateOf(initialCurve.x1) }
    var y1 by remember { mutableFloatStateOf(initialCurve.y1) }
    var x2 by remember { mutableFloatStateOf(initialCurve.x2) }
    var y2 by remember { mutableFloatStateOf(initialCurve.y2) }
    var selectedPresetName by remember { mutableStateOf(initialCurve.name) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = StudioSurfaceDark,
            border = androidx.compose.foundation.BorderStroke(1.dp, StudioSurfaceBorder),
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Curve Graph Editor",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = StudioTextPrimary
                        )
                        Text(
                            text = "Interpolation for $propertyName",
                            style = MaterialTheme.typography.bodySmall,
                            color = StudioNeonCyan
                        )
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = StudioTextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Presets Bar
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(KeyframeCurve.ALL_PRESETS) { preset ->
                        val isSelected = selectedPresetName == preset.name
                        FilterChip(
                            selected = isSelected,
                            onClick = {
                                selectedPresetName = preset.name
                                x1 = preset.x1
                                y1 = preset.y1
                                x2 = preset.x2
                                y2 = preset.y2
                            },
                            label = { Text(preset.name, fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = StudioNeonCyan,
                                selectedLabelColor = StudioDarkBackground,
                                containerColor = StudioSurfaceElevated,
                                labelColor = StudioTextPrimary
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Interactive Cubic Bezier Curve Canvas
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(240.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(StudioDarkBackground)
                        .border(1.dp, StudioSurfaceBorder, RoundedCornerShape(12.dp))
                        .padding(24.dp)
                ) {
                    Canvas(
                        modifier = Modifier
                            .fillMaxSize()
                            .pointerInput(Unit) {
                                detectDragGestures { change, dragAmount ->
                                    change.consume()
                                    val touchPos = change.position
                                    val w = size.width
                                    val h = size.height

                                    // Check distance to handle 1 vs handle 2
                                    val p1 = Offset(x1 * w, (1f - y1) * h)
                                    val p2 = Offset(x2 * w, (1f - y2) * h)

                                    val dist1 = (touchPos - p1).getDistance()
                                    val dist2 = (touchPos - p2).getDistance()

                                    if (dist1 < dist2) {
                                        x1 = (touchPos.x / w).coerceIn(0f, 1f)
                                        y1 = (1f - (touchPos.y / h)).coerceIn(0f, 1f)
                                        selectedPresetName = "Custom"
                                    } else {
                                        x2 = (touchPos.x / w).coerceIn(0f, 1f)
                                        y2 = (1f - (touchPos.y / h)).coerceIn(0f, 1f)
                                        selectedPresetName = "Custom"
                                    }
                                }
                            }
                    ) {
                        val w = size.width
                        val h = size.height

                        // Grid Lines
                        val gridPaint = StudioSurfaceBorder.copy(alpha = 0.5f)
                        for (i in 1..3) {
                            val f = i / 4f
                            drawLine(gridPaint, Offset(0f, h * f), Offset(w, h * f), strokeWidth = 1.dp.toPx())
                            drawLine(gridPaint, Offset(w * f, 0f), Offset(w * f, h), strokeWidth = 1.dp.toPx())
                        }

                        val p0 = Offset(0f, h)
                        val p3 = Offset(w, 0f)
                        val handle1 = Offset(x1 * w, (1f - y1) * h)
                        val handle2 = Offset(x2 * w, (1f - y2) * h)

                        // Tangent lines
                        drawLine(
                            color = StudioElectricPurple.copy(alpha = 0.7f),
                            start = p0,
                            end = handle1,
                            strokeWidth = 2.dp.toPx()
                        )
                        drawLine(
                            color = StudioNeonCyan.copy(alpha = 0.7f),
                            start = p3,
                            end = handle2,
                            strokeWidth = 2.dp.toPx()
                        )

                        // Bezier Path
                        val path = Path().apply {
                            moveTo(p0.x, p0.y)
                            cubicTo(handle1.x, handle1.y, handle2.x, handle2.y, p3.x, p3.y)
                        }
                        drawPath(
                            path = path,
                            color = StudioNeonCyan,
                            style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
                        )

                        // Handle 1 (In handle)
                        drawCircle(color = StudioElectricPurple, radius = 7.dp.toPx(), center = handle1)
                        drawCircle(color = Color.White, radius = 4.dp.toPx(), center = handle1)

                        // Handle 2 (Out handle)
                        drawCircle(color = StudioNeonCyan, radius = 7.dp.toPx(), center = handle2)
                        drawCircle(color = Color.White, radius = 4.dp.toPx(), center = handle2)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Parameter Readout
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "CP1: (${String.format("%.2f", x1)}, ${String.format("%.2f", y1)})",
                        style = MaterialTheme.typography.labelSmall,
                        color = StudioElectricPurple
                    )
                    Text(
                        text = "CP2: (${String.format("%.2f", x2)}, ${String.format("%.2f", y2)})",
                        style = MaterialTheme.typography.labelSmall,
                        color = StudioNeonCyan
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel", color = StudioTextSecondary)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val curve = KeyframeCurve(selectedPresetName, x1, y1, x2, y2)
                            onApplyCurve(curve)
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = StudioNeonCyan),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("apply_curve_button")
                    ) {
                        Icon(Icons.Default.Done, contentDescription = null, tint = StudioDarkBackground, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Apply Curve", color = StudioDarkBackground, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
