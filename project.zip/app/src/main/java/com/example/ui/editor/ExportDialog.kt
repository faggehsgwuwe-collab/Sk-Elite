package com.example.ui.editor

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.FileProvider
import com.example.engine.ExportProgress
import com.example.engine.VideoExportEngine
import com.example.model.Project
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

enum class ExportResolution(val label: String, val baseWidth: Int, val baseHeight: Int) {
    RES_1080P("1080p Full HD", 1080, 1920),
    RES_720P("720p HD", 720, 1280),
    RES_480P("480p SD", 480, 854)
}

@Composable
fun ExportDialog(
    project: Project,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var selectedResolution by remember { mutableStateOf(ExportResolution.RES_720P) }
    var selectedFps by remember { mutableIntStateOf(30) }

    var isExporting by remember { mutableStateOf(false) }
    var exportProgress by remember { mutableStateOf<ExportProgress?>(null) }
    var exportedFile by remember { mutableStateOf<File?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val cancellationHandle = remember { AtomicBoolean(false) }

    Dialog(onDismissRequest = {
        if (!isExporting) onDismiss()
    }) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = StudioSurfaceDark,
            border = androidx.compose.foundation.BorderStroke(1.dp, StudioSurfaceBorder),
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(StudioNeonCyan.copy(alpha = 0.15f), RoundedCornerShape(8.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.MovieCreation, contentDescription = null, tint = StudioNeonCyan, modifier = Modifier.size(20.dp))
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("Export MP4 Video", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = StudioTextPrimary)
                            Text("Hardware H.264 Encoder", style = MaterialTheme.typography.bodySmall, color = StudioTextSecondary)
                        }
                    }
                    if (!isExporting) {
                        IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = StudioTextSecondary)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                if (exportedFile != null) {
                    // Export Complete View
                    Surface(
                        color = StudioMintGreen.copy(alpha = 0.12f),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, StudioMintGreen.copy(alpha = 0.4f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = StudioMintGreen, modifier = Modifier.size(44.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Video Export Complete!", fontWeight = FontWeight.Bold, color = StudioTextPrimary, fontSize = 16.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                            val sizeMb = String.format("%.2f MB", (exportedFile!!.length() / (1024f * 1024f)))
                            Text("File: ${exportedFile!!.name} ($sizeMb)", style = MaterialTheme.typography.bodySmall, color = StudioTextSecondary)
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                val uri = FileProvider.getUriForFile(
                                    context,
                                    "${context.packageName}.fileprovider",
                                    exportedFile!!
                                )
                                val intent = Intent(Intent.ACTION_VIEW).apply {
                                    setDataAndType(uri, "video/mp4")
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                                context.startActivity(Intent.createChooser(intent, "Play Video"))
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = StudioSurfaceElevated),
                            modifier = Modifier.weight(1f).testTag("play_exported_video_button")
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, tint = StudioNeonCyan)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Play", color = StudioTextPrimary)
                        }

                        Button(
                            onClick = {
                                val uri = FileProvider.getUriForFile(
                                    context,
                                    "${context.packageName}.fileprovider",
                                    exportedFile!!
                                )
                                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "video/mp4"
                                    putExtra(Intent.EXTRA_STREAM, uri)
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                                context.startActivity(Intent.createChooser(shareIntent, "Share MP4 Video"))
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = StudioNeonCyan),
                            modifier = Modifier.weight(1f).testTag("share_exported_video_button")
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, tint = StudioDarkBackground)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Share", color = StudioDarkBackground, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    TextButton(
                        onClick = onDismiss,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Done", color = StudioTextSecondary)
                    }

                } else if (isExporting) {
                    // Export Progress View
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        val percent = exportProgress?.percentage ?: 0
                        val msg = exportProgress?.message ?: "Preparing render..."

                        LinearProgressIndicator(
                            progress = { percent / 100f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = StudioNeonCyan,
                            trackColor = StudioSurfaceBorder
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(msg, style = MaterialTheme.typography.bodySmall, color = StudioTextSecondary)
                            Text("$percent%", fontWeight = FontWeight.Bold, color = StudioNeonCyan)
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        OutlinedButton(
                            onClick = {
                                cancellationHandle.set(true)
                                isExporting = false
                                onDismiss()
                            },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = StudioCoralRed)
                        ) {
                            Text("Cancel Export")
                        }
                    }

                } else {
                    // Export Configuration View
                    Text("Select Resolution", style = MaterialTheme.typography.titleSmall, color = StudioTextPrimary)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ExportResolution.values().forEach { res ->
                            val isSelected = selectedResolution == res
                            Surface(
                                color = if (isSelected) StudioNeonCyan.copy(alpha = 0.2f) else StudioSurfaceElevated,
                                shape = RoundedCornerShape(10.dp),
                                border = androidx.compose.foundation.BorderStroke(
                                    width = if (isSelected) 1.5.dp else 1.dp,
                                    color = if (isSelected) StudioNeonCyan else StudioSurfaceBorder
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { selectedResolution = res }
                            ) {
                                Column(
                                    modifier = Modifier.padding(10.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(
                                        text = res.name.substring(4),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = if (isSelected) StudioNeonCyan else StudioTextPrimary
                                    )
                                    Text(
                                        text = if (project.width < project.height) "${res.baseWidth}p" else "${res.baseHeight}p",
                                        fontSize = 10.sp,
                                        color = StudioTextSecondary
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text("Frame Rate (FPS)", style = MaterialTheme.typography.titleSmall, color = StudioTextPrimary)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(24 to "24 Cinematic", 30 to "30 Standard", 60 to "60 Smooth").forEach { (fps, label) ->
                            val isSelected = selectedFps == fps
                            Surface(
                                color = if (isSelected) StudioElectricPurple.copy(alpha = 0.2f) else StudioSurfaceElevated,
                                shape = RoundedCornerShape(10.dp),
                                border = androidx.compose.foundation.BorderStroke(
                                    width = if (isSelected) 1.5.dp else 1.dp,
                                    color = if (isSelected) StudioElectricPurple else StudioSurfaceBorder
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { selectedFps = fps }
                            ) {
                                Column(
                                    modifier = Modifier.padding(10.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(
                                        text = "${fps} FPS",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = if (isSelected) StudioElectricPurple else StudioTextPrimary
                                    )
                                    Text(text = label.split(" ").getOrElse(1) { "" }, fontSize = 10.sp, color = StudioTextSecondary)
                                }
                            }
                        }
                    }

                    if (errorMessage != null) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(errorMessage!!, color = StudioCoralRed, style = MaterialTheme.typography.bodySmall)
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Button(
                        onClick = {
                            isExporting = true
                            errorMessage = null
                            cancellationHandle.set(false)

                            // Compute dimensions matching project aspect ratio
                            val aspect = project.width.toFloat() / project.height.toFloat()
                            val (targetW, targetH) = if (aspect < 1.0f) {
                                // Portrait (e.g. 9:16)
                                selectedResolution.baseWidth to (selectedResolution.baseWidth / aspect).toInt()
                            } else {
                                // Landscape (e.g. 16:9)
                                (selectedResolution.baseWidth * aspect).toInt() to selectedResolution.baseWidth
                            }

                            scope.launch {
                                val result = VideoExportEngine.exportVideo(
                                    context = context,
                                    project = project,
                                    targetWidth = targetW,
                                    targetHeight = targetH,
                                    fps = selectedFps,
                                    isCancelled = cancellationHandle,
                                    onProgress = { exportProgress = it }
                                )

                                isExporting = false
                                result.onSuccess { file ->
                                    exportedFile = file
                                }.onFailure { error ->
                                    errorMessage = "Export error: ${error.message}"
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = StudioNeonCyan),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("start_mp4_export_button")
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null, tint = StudioDarkBackground)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Export MP4 Video", color = StudioDarkBackground, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                }
            }
        }
    }
}
