package com.example.ui.home

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.Project
import com.example.model.ProjectAspectRatio
import com.example.model.UnsupportedXmlNode
import com.example.repository.ProjectRepository
import com.example.ui.editor.UnsupportedXmlDialog
import com.example.ui.guide.PhoneBuildGuideDialog
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    repository: ProjectRepository,
    onOpenProject: (Project) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var projects by remember { mutableStateOf<List<Project>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    var showNewProjectDialog by remember { mutableStateOf(false) }
    var showBuildGuideDialog by remember { mutableStateOf(false) }
    var importWarningsDialogData by remember { mutableStateOf<Pair<List<UnsupportedXmlNode>, List<String>>?>(null) }

    fun refreshProjects() {
        scope.launch {
            isLoading = true
            projects = repository.getAllProjects()
            isLoading = false
        }
    }

    LaunchedEffect(Unit) {
        refreshProjects()
    }

    // XML File Picker Launcher
    val xmlPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                try {
                    val (importedProject, warnings) = repository.importProjectFromUri(uri)
                    refreshProjects()
                    if (warnings.isNotEmpty() || importedProject.unsupportedNodes.isNotEmpty()) {
                        importWarningsDialogData = importedProject.unsupportedNodes to warnings
                    } else {
                        Toast.makeText(context, "Project '${importedProject.name}' imported successfully!", Toast.LENGTH_SHORT).show()
                    }
                    onOpenProject(importedProject)
                } catch (e: Exception) {
                    Toast.makeText(context, "XML parse error: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    Brush.linearGradient(listOf(StudioNeonCyan, StudioElectricPurple))
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.MovieFilter, contentDescription = null, tint = StudioDarkBackground, modifier = Modifier.size(20.dp))
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "SK MUZAMMEL",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 15.sp,
                                color = StudioTextPrimary
                            )
                            Text(
                                text = "Motion Studio",
                                fontSize = 11.sp,
                                color = StudioNeonCyan,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showBuildGuideDialog = true },
                        modifier = Modifier.testTag("open_phone_build_guide_btn")
                    ) {
                        Icon(Icons.Default.MenuBook, contentDescription = "Phone Build Guide", tint = StudioNeonCyan)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = StudioDarkBackground)
            )
        },
        containerColor = StudioDarkBackground
    ) { paddingValues ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Hero Action Section
            item {
                Spacer(modifier = Modifier.height(4.dp))
                Surface(
                    color = StudioSurfaceElevated,
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, StudioSurfaceBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Motion Graphics Studio",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 17.sp,
                                    color = StudioTextPrimary
                                )
                                Text(
                                    text = "Alight Motion XML compatible editor",
                                    fontSize = 12.sp,
                                    color = StudioTextSecondary
                                )
                            }
                            Surface(
                                color = StudioNeonCyan.copy(alpha = 0.15f),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = "PRO ENGINE",
                                    color = StudioNeonCyan,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            // Import XML Button
                            Button(
                                onClick = {
                                    xmlPickerLauncher.launch(arrayOf("text/xml", "application/xml", "*/*"))
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = StudioNeonCyan),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(46.dp)
                                    .testTag("import_xml_button")
                            ) {
                                Icon(Icons.Default.FileOpen, contentDescription = null, tint = StudioDarkBackground, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Import XML", color = StudioDarkBackground, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }

                            // Create Project Button
                            Button(
                                onClick = { showNewProjectDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = StudioElectricPurple),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(46.dp)
                                    .testTag("create_new_project_button")
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("New Project", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Test Sample XML Project Button
                        OutlinedButton(
                            onClick = {
                                scope.launch {
                                    val (sampleProject, warnings) = repository.importProjectFromXmlString(repository.getSampleXmlCode())
                                    refreshProjects()
                                    if (warnings.isNotEmpty() || sampleProject.unsupportedNodes.isNotEmpty()) {
                                        importWarningsDialogData = sampleProject.unsupportedNodes to warnings
                                    }
                                    onOpenProject(sampleProject)
                                }
                            },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = StudioMintGreen),
                            border = androidx.compose.foundation.BorderStroke(1.dp, StudioMintGreen.copy(alpha = 0.5f)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(40.dp)
                                .testTag("import_sample_xml_button")
                        ) {
                            Icon(Icons.Default.Animation, contentDescription = null, tint = StudioMintGreen, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Try Sample Alight Motion XML Project", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }

            // Recent Projects Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Projects",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = StudioTextPrimary
                    )
                    Text(
                        text = "${projects.size} saved",
                        style = MaterialTheme.typography.bodySmall,
                        color = StudioTextSecondary
                    )
                }
            }

            // Project List
            if (isLoading) {
                item {
                    Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = StudioNeonCyan)
                    }
                }
            } else if (projects.isEmpty()) {
                item {
                    Surface(
                        color = StudioSurfaceElevated,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Default.VideoLibrary, contentDescription = null, tint = StudioTextMuted, modifier = Modifier.size(48.dp))
                            Spacer(modifier = Modifier.height(10.dp))
                            Text("No projects yet", fontWeight = FontWeight.Bold, color = StudioTextPrimary)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Import an XML project or tap New Project to start", color = StudioTextSecondary, fontSize = 12.sp)
                        }
                    }
                }
            } else {
                items(projects, key = { it.id }) { proj ->
                    val dateFormat = remember { SimpleDateFormat("MMM dd, yyyy • HH:mm", Locale.getDefault()) }
                    val dateStr = dateFormat.format(Date(proj.updatedAt))

                    Surface(
                        color = StudioSurfaceElevated,
                        shape = RoundedCornerShape(14.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, StudioSurfaceBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .clickable { onOpenProject(proj) }
                            .testTag("project_item_${proj.id}")
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Aspect Preview Icon Badge
                            Box(
                                modifier = Modifier
                                    .size(52.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(proj.backgroundColor))
                                    .border(1.dp, StudioSurfaceBorder, RoundedCornerShape(8.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(
                                        imageVector = when (proj.aspectRatio) {
                                            ProjectAspectRatio.RATIO_9_16 -> Icons.Default.PhoneAndroid
                                            ProjectAspectRatio.RATIO_16_9 -> Icons.Default.Tv
                                            else -> Icons.Default.CropSquare
                                        },
                                        contentDescription = null,
                                        tint = StudioNeonCyan,
                                        modifier = Modifier.size(22.dp)
                                    )
                                    Text(
                                        text = "${proj.aspectRatio.widthRatio}:${proj.aspectRatio.heightRatio}",
                                        fontSize = 8.sp,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(14.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = proj.name,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = StudioTextPrimary,
                                    maxLines = 1
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "${proj.layers.size} layers • ${String.format("%.1fs", proj.durationMs / 1000f)} • ${proj.fps} fps",
                                    fontSize = 12.sp,
                                    color = StudioTextSecondary
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = dateStr,
                                    fontSize = 10.sp,
                                    color = StudioTextMuted
                                )
                            }

                            // Actions
                            IconButton(
                                onClick = {
                                    scope.launch {
                                        repository.deleteProject(proj.id)
                                        refreshProjects()
                                    }
                                },
                                modifier = Modifier.size(32.dp).testTag("delete_project_${proj.id}")
                            ) {
                                Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = StudioTextMuted, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }

    // New Project Dialog
    if (showNewProjectDialog) {
        NewProjectDialog(
            onDismiss = { showNewProjectDialog = false },
            onCreate = { newProj ->
                showNewProjectDialog = false
                scope.launch {
                    repository.saveProject(newProj)
                    refreshProjects()
                    onOpenProject(newProj)
                }
            }
        )
    }

    // Phone Build Guide Dialog
    if (showBuildGuideDialog) {
        PhoneBuildGuideDialog(onDismiss = { showBuildGuideDialog = false })
    }

    // XML Compatibility Warnings Dialog
    importWarningsDialogData?.let { (nodes, warnings) ->
        UnsupportedXmlDialog(
            unsupportedNodes = nodes,
            warnings = warnings,
            onDismiss = { importWarningsDialogData = null }
        )
    }
}

@Composable
fun NewProjectDialog(
    onDismiss: () -> Unit,
    onCreate: (Project) -> Unit
) {
    var name by remember { mutableStateOf("New Motion Project") }
    var selectedAspect by remember { mutableStateOf(ProjectAspectRatio.RATIO_9_16) }
    var fps by remember { mutableIntStateOf(30) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = StudioSurfaceDark,
            border = androidx.compose.foundation.BorderStroke(1.dp, StudioSurfaceBorder),
            modifier = Modifier.fillMaxWidth().padding(12.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("Create New Motion Project", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = StudioTextPrimary)
                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Project Name") },
                    modifier = Modifier.fillMaxWidth().testTag("new_project_name_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = StudioNeonCyan,
                        unfocusedBorderColor = StudioSurfaceBorder,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    )
                )

                Spacer(modifier = Modifier.height(14.dp))
                Text("Aspect Ratio", style = MaterialTheme.typography.labelMedium, color = StudioTextSecondary)
                Spacer(modifier = Modifier.height(6.dp))

                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(ProjectAspectRatio.values()) { ratio ->
                        val isSelected = selectedAspect == ratio
                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedAspect = ratio },
                            label = { Text("${ratio.widthRatio}:${ratio.heightRatio}") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = StudioNeonCyan,
                                selectedLabelColor = StudioDarkBackground,
                                containerColor = StudioSurfaceElevated,
                                labelColor = StudioTextPrimary
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel", color = StudioTextSecondary)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val (w, h) = when (selectedAspect) {
                                ProjectAspectRatio.RATIO_9_16 -> 1080 to 1920
                                ProjectAspectRatio.RATIO_16_9 -> 1920 to 1080
                                ProjectAspectRatio.RATIO_1_1 -> 1080 to 1080
                                ProjectAspectRatio.RATIO_4_5 -> 1080 to 1350
                                ProjectAspectRatio.RATIO_4_3 -> 1440 to 1080
                            }
                            val p = Project(
                                id = UUID.randomUUID().toString(),
                                name = name.ifBlank { "Untitled Motion" },
                                width = w,
                                height = h,
                                fps = fps,
                                durationMs = 5000L
                            )
                            onCreate(p)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = StudioNeonCyan),
                        modifier = Modifier.testTag("confirm_create_project_btn")
                    ) {
                        Text("Create", color = StudioDarkBackground, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
