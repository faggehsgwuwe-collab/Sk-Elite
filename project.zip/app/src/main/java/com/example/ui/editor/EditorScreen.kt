package com.example.ui.editor

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.KeyframeCurve
import com.example.model.MotionLayer
import com.example.model.Project
import com.example.parser.XmlProjectSerializer
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(
    initialProject: Project,
    onBack: () -> Unit,
    onSaveProject: (Project) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    // Current Project State
    var project by remember { mutableStateOf(initialProject) }

    // Undo / Redo history stacks
    val undoStack = remember { mutableStateListOf<Project>() }
    val redoStack = remember { mutableStateListOf<Project>() }

    fun pushUndoState(newProject: Project) {
        undoStack.add(project)
        if (undoStack.size > 25) undoStack.removeAt(0)
        redoStack.clear()
        project = newProject
        onSaveProject(newProject)
    }

    fun handleUndo() {
        if (undoStack.isNotEmpty()) {
            val prev = undoStack.removeLast()
            redoStack.add(project)
            project = prev
            onSaveProject(prev)
        }
    }

    fun handleRedo() {
        if (redoStack.isNotEmpty()) {
            val next = redoStack.removeLast()
            undoStack.add(project)
            project = next
            onSaveProject(next)
        }
    }

    // Playback state
    var currentTimeMs by remember { mutableLongStateOf(0L) }
    var isPlaying by remember { mutableStateOf(false) }

    // Selected layer
    var selectedLayerId by remember { mutableStateOf<String?>(null) }
    val selectedLayer = project.layers.firstOrNull { it.id == selectedLayerId }

    // Dialog & Sheet States
    var showAddLayerSheet by remember { mutableStateOf(false) }
    var showExportDialog by remember { mutableStateOf(false) }
    var showSettingsDialog by remember { mutableStateOf(false) }
    var showUnsupportedXmlDialog by remember { mutableStateOf(false) }
    var curveEditorConfig by remember { mutableStateOf<Pair<String, KeyframeCurve>?>(null) }
    var showXmlSourceDialog by remember { mutableStateOf(false) }

    // Bottom panel mode: TIMELINE vs INSPECTOR
    var isInspectorOpen by remember { mutableStateOf(false) }

    // Auto-pause / loop playback ticker
    LaunchedEffect(isPlaying, project.durationMs, project.fps) {
        if (isPlaying) {
            val frameIntervalMs = (1000L / project.fps).coerceAtLeast(16L)
            while (isActive && isPlaying) {
                delay(frameIntervalMs)
                currentTimeMs = (currentTimeMs + frameIntervalMs)
                if (currentTimeMs >= project.durationMs) {
                    currentTimeMs = 0L // Loop
                }
            }
        }
    }

    BackHandler {
        onSaveProject(project)
        onBack()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = project.name,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = StudioTextPrimary,
                            maxLines = 1
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "${project.aspectRatio.widthRatio}:${project.aspectRatio.heightRatio} • ${project.fps} FPS",
                                style = MaterialTheme.typography.labelSmall,
                                color = StudioTextSecondary
                            )
                            if (project.unsupportedNodes.isNotEmpty()) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    color = StudioAmberWarning.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier.clip(RoundedCornerShape(4.dp))
                                ) {
                                    Text(
                                        text = "${project.unsupportedNodes.size} XML elements preserved",
                                        fontSize = 9.sp,
                                        color = StudioAmberWarning,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                    )
                                }
                            }
                        }
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = {
                            onSaveProject(project)
                            onBack()
                        },
                        modifier = Modifier.testTag("back_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = StudioTextPrimary)
                    }
                },
                actions = {
                    // Undo
                    IconButton(
                        onClick = { handleUndo() },
                        enabled = undoStack.isNotEmpty(),
                        modifier = Modifier.testTag("undo_button")
                    ) {
                        Icon(
                            Icons.AutoMirrored.Filled.Undo,
                            contentDescription = "Undo",
                            tint = if (undoStack.isNotEmpty()) StudioTextPrimary else StudioTextMuted
                        )
                    }

                    // Redo
                    IconButton(
                        onClick = { handleRedo() },
                        enabled = redoStack.isNotEmpty(),
                        modifier = Modifier.testTag("redo_button")
                    ) {
                        Icon(
                            Icons.AutoMirrored.Filled.Redo,
                            contentDescription = "Redo",
                            tint = if (redoStack.isNotEmpty()) StudioTextPrimary else StudioTextMuted
                        )
                    }

                    // XML View / Share
                    IconButton(
                        onClick = { showXmlSourceDialog = true },
                        modifier = Modifier.testTag("xml_code_button")
                    ) {
                        Icon(Icons.Default.Code, contentDescription = "View XML Project", tint = StudioNeonCyan)
                    }

                    // Settings
                    IconButton(
                        onClick = { showSettingsDialog = true },
                        modifier = Modifier.testTag("project_settings_button")
                    ) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings", tint = StudioTextSecondary)
                    }

                    // Export MP4 Button
                    Button(
                        onClick = { showExportDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = StudioNeonCyan),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .testTag("export_mp4_action_button")
                    ) {
                        Icon(Icons.Default.Movie, contentDescription = null, tint = StudioDarkBackground, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Export", color = StudioDarkBackground, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = StudioDarkBackground,
                    titleContentColor = StudioTextPrimary
                )
            )
        },
        containerColor = StudioDarkBackground
    ) { paddingValues ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Upper Viewport: Interactive Canvas Preview
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1.05f)
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                CanvasPreview(
                    project = project,
                    currentTimeMs = currentTimeMs,
                    selectedLayerId = selectedLayerId,
                    onSelectLayer = {
                        selectedLayerId = it
                        if (it != null) isInspectorOpen = true
                    },
                    onUpdateLayerTransform = { layerId, newX, newY ->
                        val updatedLayers = project.layers.map { layer ->
                            if (layer.id == layerId) {
                                layer.copy(transform = layer.transform.copy(positionX = newX, positionY = newY))
                            } else layer
                        }
                        pushUndoState(project.copy(layers = updatedLayers))
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }

            // Middle Bar: Playback Controls and Mode Toggles
            Surface(
                color = StudioSurfaceElevated,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Transport controls
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        // Jump Start
                        IconButton(
                            onClick = { currentTimeMs = 0L },
                            modifier = Modifier.size(34.dp).testTag("jump_start_button")
                        ) {
                            Icon(Icons.Default.SkipPrevious, contentDescription = "Jump Start", tint = StudioTextSecondary, modifier = Modifier.size(20.dp))
                        }

                        // Step Back 1 Frame
                        val oneFrameMs = 1000L / project.fps
                        IconButton(
                            onClick = { currentTimeMs = (currentTimeMs - oneFrameMs).coerceAtLeast(0L) },
                            modifier = Modifier.size(34.dp).testTag("step_back_button")
                        ) {
                            Icon(Icons.Default.FastRewind, contentDescription = "Step Back", tint = StudioTextSecondary, modifier = Modifier.size(20.dp))
                        }

                        // Play / Pause
                        IconButton(
                            onClick = { isPlaying = !isPlaying },
                            modifier = Modifier
                                .size(40.dp)
                                .background(StudioNeonCyan, CircleShape)
                                .testTag("play_pause_button")
                        ) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = if (isPlaying) "Pause" else "Play",
                                tint = StudioDarkBackground,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        // Step Forward 1 Frame
                        IconButton(
                            onClick = { currentTimeMs = (currentTimeMs + oneFrameMs).coerceAtMost(project.durationMs) },
                            modifier = Modifier.size(34.dp).testTag("step_forward_button")
                        ) {
                            Icon(Icons.Default.FastForward, contentDescription = "Step Forward", tint = StudioTextSecondary, modifier = Modifier.size(20.dp))
                        }

                        // Jump End
                        IconButton(
                            onClick = { currentTimeMs = project.durationMs },
                            modifier = Modifier.size(34.dp).testTag("jump_end_button")
                        ) {
                            Icon(Icons.Default.SkipNext, contentDescription = "Jump End", tint = StudioTextSecondary, modifier = Modifier.size(20.dp))
                        }
                    }

                    // Right Actions: Inspector toggle & Add Layer (+)
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (selectedLayer != null) {
                            FilterChip(
                                selected = isInspectorOpen,
                                onClick = { isInspectorOpen = !isInspectorOpen },
                                label = {
                                    Text(
                                        text = if (isInspectorOpen) "Timeline" else "Inspector",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                },
                                leadingIcon = {
                                    Icon(
                                        imageVector = if (isInspectorOpen) Icons.Default.ViewTimeline else Icons.Default.Tune,
                                        contentDescription = null,
                                        modifier = Modifier.size(14.dp)
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = StudioElectricPurple,
                                    selectedLabelColor = StudioTextPrimary,
                                    selectedLeadingIconColor = StudioTextPrimary
                                ),
                                modifier = Modifier.testTag("toggle_inspector_chip")
                            )
                        }

                        Button(
                            onClick = { showAddLayerSheet = true },
                            colors = ButtonDefaults.buttonColors(containerColor = StudioElectricPurple),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("add_layer_button")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Layer", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }

            // Lower Section: Switchable between Timeline and Property Inspector
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(0.95f)
            ) {
                if (isInspectorOpen && selectedLayer != null) {
                    PropertyInspector(
                        layer = selectedLayer,
                        currentTimeMs = currentTimeMs,
                        onUpdateLayer = { updated ->
                            val updatedLayers = project.layers.map { if (it.id == updated.id) updated else it }
                            pushUndoState(project.copy(layers = updatedLayers))
                        },
                        onOpenCurveEditor = { prop, initialCurve ->
                            curveEditorConfig = prop to initialCurve
                        },
                        onClose = { isInspectorOpen = false },
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    TimelineView(
                        project = project,
                        currentTimeMs = currentTimeMs,
                        selectedLayerId = selectedLayerId,
                        onSeek = { currentTimeMs = it },
                        onSelectLayer = {
                            selectedLayerId = it
                            if (it != null) isInspectorOpen = true
                        },
                        onUpdateLayerTiming = { layerId, newStart, newEnd ->
                            val updated = project.layers.map {
                                if (it.id == layerId) it.copy(startTimeMs = newStart, endTimeMs = newEnd) else it
                            }
                            pushUndoState(project.copy(layers = updated))
                        },
                        onToggleVisibility = { layerId ->
                            val updated = project.layers.map {
                                if (it.id == layerId) it.copy(isVisible = !it.isVisible) else it
                            }
                            pushUndoState(project.copy(layers = updated))
                        },
                        onToggleLock = { layerId ->
                            val updated = project.layers.map {
                                if (it.id == layerId) it.copy(isLocked = !it.isLocked) else it
                            }
                            pushUndoState(project.copy(layers = updated))
                        },
                        onDeleteLayer = { layerId ->
                            val updated = project.layers.filter { it.id != layerId }
                            if (selectedLayerId == layerId) selectedLayerId = null
                            pushUndoState(project.copy(layers = updated))
                        },
                        onDuplicateLayer = { layerId ->
                            val target = project.layers.firstOrNull { it.id == layerId }
                            if (target != null) {
                                val dup = target.copy(
                                    id = java.util.UUID.randomUUID().toString(),
                                    name = "${target.name} Copy",
                                    transform = target.transform.copy(
                                        positionX = target.transform.positionX + 40f,
                                        positionY = target.transform.positionY + 40f
                                    )
                                )
                                pushUndoState(project.copy(layers = project.layers + dup))
                            }
                        },
                        onMoveLayerOrder = { from, to ->
                            val list = project.layers.toMutableList()
                            val item = list.removeAt(from)
                            list.add(to, item)
                            pushUndoState(project.copy(layers = list))
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }
    }

    // Sheets & Dialogs
    if (showAddLayerSheet) {
        AddLayerBottomSheet(
            project = project,
            currentTimeMs = currentTimeMs,
            onAddLayer = { newLayer ->
                pushUndoState(project.copy(layers = project.layers + newLayer))
                selectedLayerId = newLayer.id
                isInspectorOpen = true
            },
            onDismiss = { showAddLayerSheet = false }
        )
    }

    if (showExportDialog) {
        ExportDialog(
            project = project,
            onDismiss = { showExportDialog = false }
        )
    }

    if (showSettingsDialog) {
        ProjectSettingsDialog(
            project = project,
            onDismiss = { showSettingsDialog = false },
            onSaveSettings = { updated ->
                pushUndoState(updated)
            }
        )
    }

    if (showUnsupportedXmlDialog) {
        UnsupportedXmlDialog(
            unsupportedNodes = project.unsupportedNodes,
            warnings = emptyList(),
            onDismiss = { showUnsupportedXmlDialog = false }
        )
    }

    curveEditorConfig?.let { (propName, curve) ->
        CurveEditorDialog(
            initialCurve = curve,
            propertyName = propName,
            onDismiss = { curveEditorConfig = null },
            onApplyCurve = { newCurve ->
                if (selectedLayer != null) {
                    val updatedPosKfs = selectedLayer.positionKeyframes.map { it.copy(curve = newCurve) }
                    val updatedScaleKfs = selectedLayer.scaleKeyframes.map { it.copy(curve = newCurve) }
                    val updatedRotKfs = selectedLayer.rotationKeyframes.map { it.copy(curve = newCurve) }
                    val updatedOpKfs = selectedLayer.opacityKeyframes.map { it.copy(curve = newCurve) }
                    val updatedLayer = selectedLayer.copy(
                        positionKeyframes = updatedPosKfs,
                        scaleKeyframes = updatedScaleKfs,
                        rotationKeyframes = updatedRotKfs,
                        opacityKeyframes = updatedOpKfs
                    )
                    val updatedLayers = project.layers.map { if (it.id == updatedLayer.id) updatedLayer else it }
                    pushUndoState(project.copy(layers = updatedLayers))
                }
            }
        )
    }

    if (showXmlSourceDialog) {
        val xmlSource = XmlProjectSerializer.serialize(project)
        AlertDialog(
            onDismissRequest = { showXmlSourceDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Code, contentDescription = null, tint = StudioNeonCyan)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Alight Motion XML Source", fontWeight = FontWeight.Bold, color = StudioTextPrimary)
                }
            },
            text = {
                Column {
                    Text(
                        "This standard XML can be imported into Alight Motion or re-imported here at any time.",
                        style = MaterialTheme.typography.bodySmall,
                        color = StudioTextSecondary
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        color = StudioDarkBackground,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 240.dp)
                    ) {
                        Text(
                            text = xmlSource,
                            style = MaterialTheme.typography.bodySmall,
                            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                            fontSize = 10.sp,
                            color = StudioTextPrimary,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        val clip = ClipData.newPlainText("Motion Studio XML", xmlSource)
                        clipboard.setPrimaryClip(clip)
                        Toast.makeText(context, "XML copied to clipboard!", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StudioNeonCyan)
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null, tint = StudioDarkBackground, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Copy XML", color = StudioDarkBackground, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showXmlSourceDialog = false }) {
                    Text("Close", color = StudioTextSecondary)
                }
            },
            containerColor = StudioSurfaceDark
        )
    }
}
