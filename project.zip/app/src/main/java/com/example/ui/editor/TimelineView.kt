package com.example.ui.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.LayerType
import com.example.model.MotionLayer
import com.example.model.Project
import com.example.ui.theme.*

@Composable
fun TimelineView(
    project: Project,
    currentTimeMs: Long,
    selectedLayerId: String?,
    onSeek: (Long) -> Unit,
    onSelectLayer: (String?) -> Unit,
    onUpdateLayerTiming: (layerId: String, newStartMs: Long, newEndMs: Long) -> Unit,
    onToggleVisibility: (layerId: String) -> Unit,
    onToggleLock: (layerId: String) -> Unit,
    onDeleteLayer: (layerId: String) -> Unit,
    onDuplicateLayer: (layerId: String) -> Unit,
    onMoveLayerOrder: (fromIndex: Int, toIndex: Int) -> Unit,
    modifier: Modifier = Modifier
) {
    var pixelsPerSecond by remember { mutableFloatStateOf(100f) } // Timeline zoom
    val totalSeconds = (project.durationMs / 1000f).coerceAtLeast(1f)
    val timelineWidthDp = (totalSeconds * pixelsPerSecond).coerceAtLeast(400f)

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(StudioSurfaceDark)
            .border(1.dp, StudioSurfaceBorder)
    ) {
        // Timeline Header: Scrubber Info and Zoom Controls
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Time readout
            val currentSec = currentTimeMs / 1000f
            val totalSec = project.durationMs / 1000f
            val currentFrame = project.msToFrame(currentTimeMs)
            val totalFrame = project.totalFrames

            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    color = StudioSurfaceElevated,
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = String.format("%02d:%02d.%02d", (currentSec / 60).toInt(), (currentSec % 60).toInt(), ((currentSec * 100) % 100).toInt()),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = StudioNeonCyan,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                }
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "/ ${String.format("%.1fs", totalSec)} (F: $currentFrame/$totalFrame)",
                    style = MaterialTheme.typography.bodySmall,
                    color = StudioTextSecondary
                )
            }

            // Timeline Zoom Buttons
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = { pixelsPerSecond = (pixelsPerSecond - 25f).coerceAtLeast(50f) },
                    modifier = Modifier.size(32.dp).testTag("zoom_out_timeline")
                ) {
                    Icon(Icons.Default.Remove, contentDescription = "Zoom Out Timeline", tint = StudioTextSecondary, modifier = Modifier.size(18.dp))
                }
                Text(
                    text = "${pixelsPerSecond.toInt()}px/s",
                    style = MaterialTheme.typography.labelSmall,
                    color = StudioTextMuted,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
                IconButton(
                    onClick = { pixelsPerSecond = (pixelsPerSecond + 25f).coerceAtMost(300f) },
                    modifier = Modifier.size(32.dp).testTag("zoom_in_timeline")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Zoom In Timeline", tint = StudioTextSecondary, modifier = Modifier.size(18.dp))
                }
            }
        }

        Divider(color = StudioSurfaceBorder, thickness = 1.dp)

        // Ruler + Layer Tracks Scrollable Area
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .horizontalScroll(scrollState)
        ) {
            Column(modifier = Modifier.width(timelineWidthDp.dp)) {
                // Time Ruler
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(28.dp)
                        .background(StudioSurfaceElevated)
                        .pointerInput(project.durationMs, pixelsPerSecond) {
                            detectTapGestures { offset ->
                                val timeMs = ((offset.x / pixelsPerSecond) * 1000L).toLong().coerceIn(0L, project.durationMs)
                                onSeek(timeMs)
                            }
                        }
                        .pointerInput(project.durationMs, pixelsPerSecond) {
                            detectDragGestures { change, _ ->
                                change.consume()
                                val timeMs = ((change.position.x / pixelsPerSecond) * 1000L).toLong().coerceIn(0L, project.durationMs)
                                onSeek(timeMs)
                            }
                        }
                ) {
                    // Draw tick marks
                    val numSeconds = (project.durationMs / 1000L).toInt() + 1
                    for (sec in 0 until numSeconds) {
                        val xDp = (sec * pixelsPerSecond)
                        Box(
                            modifier = Modifier
                                .offset(x = xDp.dp)
                                .width(1.dp)
                                .height(if (sec % 5 == 0) 24.dp else 12.dp)
                                .background(StudioTextMuted.copy(alpha = 0.6f))
                        )
                        if (sec % 1 == 0) {
                            Text(
                                text = "${sec}s",
                                fontSize = 9.sp,
                                color = StudioTextSecondary,
                                modifier = Modifier.offset(x = (xDp + 4).dp, y = 2.dp)
                            )
                        }
                    }
                }

                Divider(color = StudioSurfaceBorder, thickness = 1.dp)

                // Layer Track Rows
                LazyColumn(
                    modifier = Modifier.fillMaxWidth().weight(1f)
                ) {
                    itemsIndexed(project.layers, key = { _, layer -> layer.id }) { index, layer ->
                        val isSelected = layer.id == selectedLayerId
                        val startSec = layer.startTimeMs / 1000f
                        val endSec = layer.endTimeMs / 1000f
                        val layerDurationSec = (endSec - startSec).coerceAtLeast(0.1f)

                        val startXDp = (startSec * pixelsPerSecond)
                        val clipWidthDp = (layerDurationSec * pixelsPerSecond)

                        val clipColor = when (layer.type) {
                            LayerType.SHAPE -> TimelineClipShape
                            LayerType.TEXT -> TimelineClipText
                            LayerType.IMAGE -> TimelineClipImage
                            LayerType.VIDEO -> TimelineClipVideo
                            LayerType.AUDIO -> TimelineClipAudio
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                                .background(if (isSelected) StudioSurfaceElevated else Color.Transparent)
                                .clickable { onSelectLayer(layer.id) }
                                .padding(vertical = 3.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(modifier = Modifier.fillMaxSize()) {
                                // Layer Clip Bar
                                Box(
                                    modifier = Modifier
                                        .offset(x = startXDp.dp)
                                        .width(clipWidthDp.dp)
                                        .fillMaxHeight()
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(clipColor.copy(alpha = if (layer.isVisible) 0.85f else 0.35f))
                                        .border(
                                            width = if (isSelected) 2.dp else 1.dp,
                                            color = if (isSelected) StudioNeonCyan else clipColor,
                                            shape = RoundedCornerShape(6.dp)
                                        )
                                        .pointerInput(layer.id, pixelsPerSecond) {
                                            detectDragGestures { change, dragAmount ->
                                                change.consume()
                                                val deltaMs = ((dragAmount.x / pixelsPerSecond) * 1000L).toLong()
                                                val currentSpan = layer.endTimeMs - layer.startTimeMs
                                                val newStart = (layer.startTimeMs + deltaMs).coerceIn(0L, project.durationMs - currentSpan)
                                                val newEnd = newStart + currentSpan
                                                onUpdateLayerTiming(layer.id, newStart, newEnd)
                                            }
                                        }
                                        .padding(horizontal = 6.dp),
                                    contentAlignment = Alignment.CenterStart
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Icon(
                                            imageVector = when (layer.type) {
                                                LayerType.SHAPE -> Icons.Default.Category
                                                LayerType.TEXT -> Icons.Default.TextFields
                                                LayerType.IMAGE -> Icons.Default.Image
                                                LayerType.VIDEO -> Icons.Default.Movie
                                                LayerType.AUDIO -> Icons.Default.Audiotrack
                                            },
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = layer.name,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color.White,
                                            maxLines = 1,
                                            modifier = Modifier.weight(1f)
                                        )

                                        // Keyframe diamond count badge
                                        val totalKeyframes = layer.positionKeyframes.size + layer.scaleKeyframes.size +
                                                layer.rotationKeyframes.size + layer.opacityKeyframes.size
                                        if (totalKeyframes > 0) {
                                            Surface(
                                                color = TimelineKeyframeNode,
                                                shape = RoundedCornerShape(3.dp)
                                            ) {
                                                Text(
                                                    text = "$totalKeyframes KF",
                                                    fontSize = 8.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color.Black,
                                                    modifier = Modifier.padding(horizontal = 3.dp, vertical = 1.dp)
                                                )
                                            }
                                        }
                                    }

                                    // Display keyframe diamond icons on the clip
                                    val allKeyframeTimes = (layer.positionKeyframes.map { it.timeMs } +
                                            layer.scaleKeyframes.map { it.timeMs } +
                                            layer.rotationKeyframes.map { it.timeMs } +
                                            layer.opacityKeyframes.map { it.timeMs }).distinct()

                                    for (kfTime in allKeyframeTimes) {
                                        val kfSec = (kfTime - layer.startTimeMs) / 1000f
                                        val kfXDp = (kfSec * pixelsPerSecond)
                                        if (kfXDp in 0f..clipWidthDp) {
                                            Box(
                                                modifier = Modifier
                                                    .offset(x = kfXDp.dp - 4.dp, y = 14.dp)
                                                    .size(7.dp)
                                                    .background(TimelineKeyframeNode, RoundedCornerShape(1.dp))
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Playhead indicator (Red vertical line spanning the whole height)
            val playheadXDp = (currentTimeMs / 1000f) * pixelsPerSecond
            Box(
                modifier = Modifier
                    .offset(x = playheadXDp.dp)
                    .width(2.dp)
                    .fillMaxHeight()
                    .background(TimelinePlayhead)
            ) {
                // Playhead thumb
                Box(
                    modifier = Modifier
                        .offset(x = (-6).dp, y = 0.dp)
                        .size(14.dp)
                        .background(TimelinePlayhead, CircleShape)
                        .border(1.dp, Color.White, CircleShape)
                )
            }
        }
    }
}
