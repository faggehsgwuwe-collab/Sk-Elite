package com.example.ui.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.Project
import com.example.model.ProjectAspectRatio
import com.example.ui.theme.*

@Composable
fun ProjectSettingsDialog(
    project: Project,
    onDismiss: () -> Unit,
    onSaveSettings: (Project) -> Unit
) {
    var name by remember { mutableStateOf(project.name) }
    var selectedAspect by remember { mutableStateOf(project.aspectRatio) }
    var durationSeconds by remember { mutableFloatStateOf(project.durationMs / 1000f) }
    var fps by remember { mutableIntStateOf(project.fps) }
    var bgColor by remember { mutableStateOf(project.backgroundColor) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = StudioSurfaceDark,
            border = androidx.compose.foundation.BorderStroke(1.dp, StudioSurfaceBorder),
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Settings, contentDescription = null, tint = StudioNeonCyan)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Project Settings", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = StudioTextPrimary)
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = StudioTextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Project Name
                Text("Project Name", style = MaterialTheme.typography.labelMedium, color = StudioTextSecondary)
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    modifier = Modifier.fillMaxWidth().testTag("project_name_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = StudioNeonCyan,
                        unfocusedBorderColor = StudioSurfaceBorder,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    )
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Aspect Ratio Selector
                Text("Aspect Ratio", style = MaterialTheme.typography.labelMedium, color = StudioTextSecondary)
                Spacer(modifier = Modifier.height(6.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(ProjectAspectRatio.values()) { ratio ->
                        val isSelected = selectedAspect == ratio
                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedAspect = ratio },
                            label = { Text("${ratio.widthRatio}:${ratio.heightRatio}", fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = StudioNeonCyan,
                                selectedLabelColor = StudioDarkBackground,
                                containerColor = StudioSurfaceElevated,
                                labelColor = StudioTextPrimary
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Duration Slider
                Text("Duration: ${String.format("%.1fs", durationSeconds)} (${(durationSeconds * fps).toInt()} frames)", style = MaterialTheme.typography.labelMedium, color = StudioTextSecondary)
                Slider(
                    value = durationSeconds,
                    onValueChange = { durationSeconds = it },
                    valueRange = 1f..30f,
                    steps = 28,
                    colors = SliderDefaults.colors(thumbColor = StudioNeonCyan, activeTrackColor = StudioNeonCyan)
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Canvas Background Color
                Text("Background Color", style = MaterialTheme.typography.labelMedium, color = StudioTextSecondary)
                Spacer(modifier = Modifier.height(6.dp))
                ColorPaletteRow(
                    selectedColor = bgColor,
                    onSelectColor = { bgColor = it }
                )

                Spacer(modifier = Modifier.height(20.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel", color = StudioTextSecondary)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val (w, h) = when (selectedAspect) {
                                ProjectAspectRatio.RATIO_9_16 -> 1080 to 1920
                                ProjectAspectRatio.RATIO_16_9 -> 1920 to 1080
                                ProjectAspectRatio.RATIO_1_1 -> 1080 to 1080
                                ProjectAspectRatio.RATIO_4_5 -> 1080 to 1350
                                ProjectAspectRatio.RATIO_4_3 -> 1440 to 1080
                            }
                            val updated = project.copy(
                                name = name.ifBlank { "Untitled Project" },
                                width = w,
                                height = h,
                                fps = fps,
                                durationMs = (durationSeconds * 1000).toLong(),
                                backgroundColor = bgColor,
                                updatedAt = System.currentTimeMillis()
                            )
                            onSaveSettings(updated)
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = StudioNeonCyan),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("save_project_settings_btn")
                    ) {
                        Icon(Icons.Default.Done, contentDescription = null, tint = StudioDarkBackground, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Apply", color = StudioDarkBackground, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
