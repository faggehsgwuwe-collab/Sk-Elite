package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val StudioDarkBackground = Color(0xFF0D0F17)
val StudioSurfaceDark = Color(0xFF161926)
val StudioSurfaceElevated = Color(0xFF202538)
val StudioSurfaceBorder = Color(0xFF2E344E)

val StudioNeonCyan = Color(0xFF00E5FF)
val StudioCyanGradientEnd = Color(0xFF00B0FF)
val StudioElectricPurple = Color(0xFF7C4DFF)
val StudioPurpleLight = Color(0xFFB388FF)
val StudioMintGreen = Color(0xFF00E676)
val StudioAmberWarning = Color(0xFFFFB300)
val StudioCoralRed = Color(0xFFFF5252)

val StudioTextPrimary = Color(0xFFF0F3FA)
val StudioTextSecondary = Color(0xFFA0A8C0)
val StudioTextMuted = Color(0xFF656D8A)

// Timeline specific
val TimelineTrackBg = Color(0xFF131622)
val TimelineClipShape = Color(0xFF2979FF)
val TimelineClipText = Color(0xFFFF4081)
val TimelineClipImage = Color(0xFF00E676)
val TimelineClipVideo = Color(0xFFFF9100)
val TimelineClipAudio = Color(0xFF7C4DFF)
val TimelinePlayhead = Color(0xFFFF1744)
val TimelineKeyframeNode = Color(0xFFFFEA00)
