package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DarkColorScheme = darkColorScheme(
    primary = StudioNeonCyan,
    onPrimary = StudioDarkBackground,
    primaryContainer = StudioElectricPurple,
    onPrimaryContainer = StudioTextPrimary,
    secondary = StudioElectricPurple,
    onSecondary = StudioTextPrimary,
    secondaryContainer = StudioSurfaceElevated,
    onSecondaryContainer = StudioTextPrimary,
    tertiary = StudioMintGreen,
    onTertiary = StudioDarkBackground,
    background = StudioDarkBackground,
    onBackground = StudioTextPrimary,
    surface = StudioSurfaceDark,
    onSurface = StudioTextPrimary,
    surfaceVariant = StudioSurfaceElevated,
    onSurfaceVariant = StudioTextSecondary,
    outline = StudioSurfaceBorder,
    error = StudioCoralRed,
    onError = StudioTextPrimary
)

@Composable
fun MotionStudioTheme(
    darkTheme: Boolean = true, // Editor is always dark themed for professional aesthetic
    content: @Composable () -> Unit
) {
    val colorScheme = DarkColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = StudioDarkBackground.toArgb()
                window.navigationBarColor = StudioDarkBackground.toArgb()
                WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
                WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = false
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

// Backward compatibility alias
@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    MotionStudioTheme(darkTheme = true, content = content)
}
