package com.example.parser

import android.graphics.Color as AndroidColor
import com.example.model.*
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.InputStream
import java.io.StringReader
import java.io.StringWriter
import java.util.UUID

data class XmlParseResult(
    val project: Project,
    val warnings: List<String>,
    val unsupportedNodes: List<UnsupportedXmlNode>
)

object XmlProjectParser {

    fun parse(xmlContent: String): XmlParseResult {
        val factory = XmlPullParserFactory.newInstance()
        factory.isNamespaceAware = false
        val parser = factory.newPullParser()
        parser.setInput(StringReader(xmlContent))

        val warnings = mutableListOf<String>()
        val unsupportedNodes = mutableListOf<UnsupportedXmlNode>()
        val layers = mutableListOf<MotionLayer>()

        var projectName = "Imported Project"
        var width = 1080
        var height = 1920
        var fps = 30
        var durationMs = 5000L
        var backgroundColor = 0xFF12141CL

        var eventType = parser.eventType
        var currentLayerBuilder: LayerBuilder? = null
        var insideTransform = false
        var currentPropertyName = ""

        while (eventType != XmlPullParser.END_DOCUMENT) {
            val tagName = parser.name ?: ""

            when (eventType) {
                XmlPullParser.START_TAG -> {
                    when (tagName.lowercase()) {
                        "scene", "project", "alightmotion", "motionproject", "motion_project" -> {
                            // Extract project attributes
                            for (i in 0 until parser.attributeCount) {
                                val attr = parser.getAttributeName(i).lowercase()
                                val value = parser.getAttributeValue(i)
                                when (attr) {
                                    "name", "title" -> projectName = value
                                    "width", "w" -> value.toIntOrNull()?.let { width = it }
                                    "height", "h" -> value.toIntOrNull()?.let { height = it }
                                    "fps", "framerate" -> value.toIntOrNull()?.let { fps = it }
                                    "totaltime", "duration", "time" -> {
                                        val num = value.toDoubleOrNull() ?: 5000.0
                                        // If duration is specified in seconds (< 100), convert to ms
                                        durationMs = if (num < 100.0) (num * 1000).toLong() else num.toLong()
                                    }
                                    "bgcolor", "background", "backgroundcolor" -> {
                                        parseColorSafe(value)?.let { backgroundColor = it }
                                    }
                                }
                            }
                        }

                        "shape", "rect", "circle", "star", "triangle" -> {
                            currentLayerBuilder = LayerBuilder(
                                id = UUID.randomUUID().toString(),
                                name = parser.getAttributeValue(null, "name") ?: "Shape Layer",
                                type = LayerType.SHAPE,
                                shapeType = when (tagName.lowercase()) {
                                    "circle" -> ShapeType.CIRCLE
                                    "star" -> ShapeType.STAR
                                    "triangle" -> ShapeType.TRIANGLE
                                    else -> {
                                        val t = parser.getAttributeValue(null, "type")?.lowercase()
                                        when (t) {
                                            "circle" -> ShapeType.CIRCLE
                                            "star" -> ShapeType.STAR
                                            "triangle" -> ShapeType.TRIANGLE
                                            "heart" -> ShapeType.HEART
                                            "roundrect", "rounded_rect" -> ShapeType.ROUNDED_RECT
                                            else -> ShapeType.RECTANGLE
                                        }
                                    }
                                }
                            )
                            parseCommonLayerAttrs(parser, currentLayerBuilder, durationMs)
                        }

                        "text", "label" -> {
                            currentLayerBuilder = LayerBuilder(
                                id = UUID.randomUUID().toString(),
                                name = parser.getAttributeValue(null, "name") ?: "Text Layer",
                                type = LayerType.TEXT
                            )
                            parseCommonLayerAttrs(parser, currentLayerBuilder, durationMs)
                            parser.getAttributeValue(null, "text")?.let { currentLayerBuilder.text = it }
                            parser.getAttributeValue(null, "size")?.toFloatOrNull()?.let { currentLayerBuilder.textSize = it }
                            parser.getAttributeValue(null, "color")?.let { parseColorSafe(it)?.let { c -> currentLayerBuilder.textColor = c } }
                        }

                        "media", "image" -> {
                            currentLayerBuilder = LayerBuilder(
                                id = UUID.randomUUID().toString(),
                                name = parser.getAttributeValue(null, "name") ?: "Image Layer",
                                type = LayerType.IMAGE
                            )
                            parseCommonLayerAttrs(parser, currentLayerBuilder, durationMs)
                            val uri = parser.getAttributeValue(null, "src")
                                ?: parser.getAttributeValue(null, "uri")
                                ?: parser.getAttributeValue(null, "path")
                            currentLayerBuilder.mediaUri = uri
                        }

                        "video" -> {
                            currentLayerBuilder = LayerBuilder(
                                id = UUID.randomUUID().toString(),
                                name = parser.getAttributeValue(null, "name") ?: "Video Layer",
                                type = LayerType.VIDEO
                            )
                            parseCommonLayerAttrs(parser, currentLayerBuilder, durationMs)
                            val uri = parser.getAttributeValue(null, "src")
                                ?: parser.getAttributeValue(null, "uri")
                            currentLayerBuilder.mediaUri = uri
                        }

                        "audio", "sound" -> {
                            currentLayerBuilder = LayerBuilder(
                                id = UUID.randomUUID().toString(),
                                name = parser.getAttributeValue(null, "name") ?: "Audio Track",
                                type = LayerType.AUDIO
                            )
                            parseCommonLayerAttrs(parser, currentLayerBuilder, durationMs)
                            val uri = parser.getAttributeValue(null, "src")
                                ?: parser.getAttributeValue(null, "uri")
                            currentLayerBuilder.mediaUri = uri
                            parser.getAttributeValue(null, "volume")?.toFloatOrNull()?.let { currentLayerBuilder.audioVolume = it }
                        }

                        "transform" -> {
                            insideTransform = true
                        }

                        "property" -> {
                            currentPropertyName = parser.getAttributeValue(null, "name")?.lowercase() ?: ""
                        }

                        "keyframe" -> {
                            val timeStr = parser.getAttributeValue(null, "time") ?: "0"
                            val timeVal = timeStr.toDoubleOrNull() ?: 0.0
                            val timeMs = if (timeVal < 100.0) (timeVal * 1000).toLong() else timeVal.toLong()

                            val valStr = parser.getAttributeValue(null, "value") ?: "0"
                            val curveStr = parser.getAttributeValue(null, "curve")
                            val curve = parseCurve(curveStr)

                            currentLayerBuilder?.let { builder ->
                                when (currentPropertyName) {
                                    "position", "pos", "location" -> {
                                        val parts = valStr.split(",").mapNotNull { it.trim().toFloatOrNull() }
                                        if (parts.size >= 2) {
                                            builder.positionKeyframes.add(Keyframe(timeMs, Point2D(parts[0], parts[1]), curve))
                                        }
                                    }
                                    "scale", "size" -> {
                                        val parts = valStr.split(",").mapNotNull { it.trim().toFloatOrNull() }
                                        val pt = if (parts.size >= 2) Point2D(parts[0], parts[1]) else Point2D(parts.getOrElse(0) { 1f }, parts.getOrElse(0) { 1f })
                                        builder.scaleKeyframes.add(Keyframe(timeMs, pt, curve))
                                    }
                                    "rotation", "angle", "rot" -> {
                                        val rot = valStr.toFloatOrNull() ?: 0f
                                        builder.rotationKeyframes.add(Keyframe(timeMs, rot, curve))
                                    }
                                    "opacity", "alpha" -> {
                                        val op = valStr.toFloatOrNull() ?: 1.0f
                                        builder.opacityKeyframes.add(Keyframe(timeMs, op, curve))
                                    }
                                    else -> {
                                        // Store unsupported keyframed property
                                        builder.customAttributes["kf_${currentPropertyName}_${timeMs}"] = valStr
                                    }
                                }
                            }
                        }

                        "fill" -> {
                            val col = parser.getAttributeValue(null, "color")
                            if (col != null) {
                                parseColorSafe(col)?.let { currentLayerBuilder?.fillColor = it }
                            }
                        }

                        "stroke" -> {
                            val col = parser.getAttributeValue(null, "color")
                            val widthStr = parser.getAttributeValue(null, "width")
                            if (col != null) {
                                parseColorSafe(col)?.let { currentLayerBuilder?.strokeColor = it }
                            }
                            widthStr?.toFloatOrNull()?.let { currentLayerBuilder?.strokeWidth = it }
                        }

                        "effect" -> {
                            val effType = parser.getAttributeValue(null, "type")?.uppercase() ?: "UNKNOWN"
                            val isSupported = effType in listOf("GLOW", "STROKE", "SHADOW", "BLUR", "TINT")
                            if (isSupported) {
                                val effColor = parser.getAttributeValue(null, "color")?.let { parseColorSafe(it) } ?: 0xFF00E5FF
                                currentLayerBuilder?.effects?.add(LayerEffect(type = effType, color = effColor))
                            } else {
                                val attrs = mutableMapOf<String, String>()
                                for (i in 0 until parser.attributeCount) {
                                    attrs[parser.getAttributeName(i)] = parser.getAttributeValue(i)
                                }
                                val node = UnsupportedXmlNode(
                                    tagName = "effect:$effType",
                                    attributes = attrs,
                                    reason = "Effect '$effType' is preserved for future Alight Motion shader compatibility"
                                )
                                unsupportedNodes.add(node)
                                warnings.add("Alight Motion effect '$effType' is preserved but not yet rendered in preview.")
                            }
                        }

                        else -> {
                            // Check if this is an unknown top-level or layer node
                            val attrs = mutableMapOf<String, String>()
                            for (i in 0 until parser.attributeCount) {
                                attrs[parser.getAttributeName(i)] = parser.getAttributeValue(i)
                            }
                            val node = UnsupportedXmlNode(
                                tagName = tagName,
                                attributes = attrs,
                                reason = "Node <$tagName> preserved to protect project integrity"
                            )
                            if (currentLayerBuilder != null) {
                                currentLayerBuilder.unsupportedChildren.add(node)
                            } else {
                                unsupportedNodes.add(node)
                            }
                            warnings.add("Preserved unsupported XML tag <$tagName> without loss.")
                        }
                    }
                }

                XmlPullParser.TEXT -> {
                    val textVal = parser.text?.trim()
                    if (!textVal.isNullOrEmpty() && currentLayerBuilder != null) {
                        if (currentLayerBuilder.type == LayerType.TEXT && currentLayerBuilder.text == "Motion Text") {
                            currentLayerBuilder.text = textVal
                        }
                    }
                }

                XmlPullParser.END_TAG -> {
                    when (tagName.lowercase()) {
                        "shape", "rect", "circle", "star", "triangle", "text", "label", "media", "image", "video", "audio", "sound" -> {
                            currentLayerBuilder?.let { builder ->
                                layers.add(builder.build())
                            }
                            currentLayerBuilder = null
                        }
                        "transform" -> {
                            insideTransform = false
                        }
                        "property" -> {
                            currentPropertyName = ""
                        }
                    }
                }
            }
            eventType = parser.next()
        }

        val project = Project(
            id = UUID.randomUUID().toString(),
            name = projectName,
            width = width,
            height = height,
            fps = fps,
            durationMs = durationMs,
            backgroundColor = backgroundColor,
            layers = layers,
            unsupportedNodes = unsupportedNodes,
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis()
        )

        return XmlParseResult(
            project = project,
            warnings = warnings.distinct(),
            unsupportedNodes = unsupportedNodes
        )
    }

    private fun parseCommonLayerAttrs(parser: XmlPullParser, builder: LayerBuilder, projectDurationMs: Long) {
        val startVal = parser.getAttributeValue(null, "startTime")
            ?: parser.getAttributeValue(null, "start")
            ?: "0"
        val endVal = parser.getAttributeValue(null, "endTime")
            ?: parser.getAttributeValue(null, "end")
            ?: "$projectDurationMs"

        val s = startVal.toDoubleOrNull() ?: 0.0
        val e = endVal.toDoubleOrNull() ?: (projectDurationMs.toDouble())
        builder.startTimeMs = if (s < 100.0 && s > 0.0) (s * 1000).toLong() else s.toLong()
        builder.endTimeMs = if (e < 100.0 && e > 0.0) (e * 1000).toLong() else e.toLong()

        // Base transform attrs if present directly on tag
        val x = parser.getAttributeValue(null, "x")?.toFloatOrNull()
        val y = parser.getAttributeValue(null, "y")?.toFloatOrNull()
        if (x != null || y != null) {
            builder.transform = builder.transform.copy(
                positionX = x ?: builder.transform.positionX,
                positionY = y ?: builder.transform.positionY
            )
        }
        val sx = parser.getAttributeValue(null, "scaleX")?.toFloatOrNull()
        val sy = parser.getAttributeValue(null, "scaleY")?.toFloatOrNull()
            ?: parser.getAttributeValue(null, "scale")?.toFloatOrNull()
        if (sx != null || sy != null) {
            builder.transform = builder.transform.copy(
                scaleX = sx ?: builder.transform.scaleX,
                scaleY = sy ?: builder.transform.scaleY
            )
        }
        val rot = parser.getAttributeValue(null, "rotation")?.toFloatOrNull()
        if (rot != null) {
            builder.transform = builder.transform.copy(rotation = rot)
        }
        val op = parser.getAttributeValue(null, "opacity")?.toFloatOrNull()
        if (op != null) {
            builder.transform = builder.transform.copy(opacity = op)
        }

        // Shape specifics
        parser.getAttributeValue(null, "width")?.toFloatOrNull()?.let { builder.width = it }
        parser.getAttributeValue(null, "height")?.toFloatOrNull()?.let { builder.height = it }
        parser.getAttributeValue(null, "fill")?.let { parseColorSafe(it)?.let { c -> builder.fillColor = c } }
        parser.getAttributeValue(null, "cornerRadius")?.toFloatOrNull()?.let { builder.cornerRadius = it }
    }

    private fun parseCurve(curveStr: String?): KeyframeCurve {
        if (curveStr.isNullOrBlank()) return KeyframeCurve.EASE_IN_OUT
        val parts = curveStr.split(",").mapNotNull { it.trim().toFloatOrNull() }
        return if (parts.size >= 4) {
            KeyframeCurve("Custom", parts[0], parts[1], parts[2], parts[3])
        } else {
            when (curveStr.lowercase()) {
                "linear" -> KeyframeCurve.LINEAR
                "easein", "ease_in" -> KeyframeCurve.EASE_IN
                "easeout", "ease_out" -> KeyframeCurve.EASE_OUT
                "bounce" -> KeyframeCurve.BOUNCE_IN
                else -> KeyframeCurve.EASE_IN_OUT
            }
        }
    }

    fun parseColorSafe(colorStr: String): Long? {
        val clean = colorStr.trim()
        return try {
            if (clean.startsWith("#")) {
                val parsed = AndroidColor.parseColor(clean)
                (parsed.toLong() and 0xFFFFFFFFL)
            } else if (clean.startsWith("0x", ignoreCase = true)) {
                clean.substring(2).toLong(16)
            } else {
                null
            }
        } catch (e: Exception) {
            null
        }
    }

    private class LayerBuilder(
        val id: String,
        val name: String,
        val type: LayerType,
        var startTimeMs: Long = 0L,
        var endTimeMs: Long = 5000L,
        var transform: LayerTransform = LayerTransform(),
        var shapeType: ShapeType = ShapeType.RECTANGLE,
        var width: Float = 400f,
        var height: Float = 300f,
        var fillColor: Long = 0xFF00E5FF,
        var strokeColor: Long = 0xFFFFFFFF,
        var strokeWidth: Float = 0f,
        var cornerRadius: Float = 24f,
        var text: String = "Motion Text",
        var textSize: Float = 64f,
        var textColor: Long = 0xFFFFFFFF,
        var mediaUri: String? = null,
        var audioVolume: Float = 1.0f,
        val positionKeyframes: MutableList<Keyframe<Point2D>> = mutableListOf(),
        val scaleKeyframes: MutableList<Keyframe<Point2D>> = mutableListOf(),
        val rotationKeyframes: MutableList<Keyframe<Float>> = mutableListOf(),
        val opacityKeyframes: MutableList<Keyframe<Float>> = mutableListOf(),
        val effects: MutableList<LayerEffect> = mutableListOf(),
        val customAttributes: MutableMap<String, String> = mutableMapOf(),
        val unsupportedChildren: MutableList<UnsupportedXmlNode> = mutableListOf()
    ) {
        fun build(): MotionLayer {
            return MotionLayer(
                id = id,
                name = name,
                type = type,
                startTimeMs = startTimeMs,
                endTimeMs = endTimeMs,
                transform = transform,
                positionKeyframes = positionKeyframes.sortedBy { it.timeMs },
                scaleKeyframes = scaleKeyframes.sortedBy { it.timeMs },
                rotationKeyframes = rotationKeyframes.sortedBy { it.timeMs },
                opacityKeyframes = opacityKeyframes.sortedBy { it.timeMs },
                shapeType = shapeType,
                width = width,
                height = height,
                fillColor = fillColor,
                strokeColor = strokeColor,
                strokeWidth = strokeWidth,
                cornerRadius = cornerRadius,
                text = text,
                textSize = textSize,
                textColor = textColor,
                mediaUri = mediaUri,
                audioVolume = audioVolume,
                effects = effects,
                customXmlAttributes = customAttributes,
                customXmlChildren = unsupportedChildren
            )
        }
    }
}
