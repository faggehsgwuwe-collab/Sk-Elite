package com.example.parser

import com.example.model.LayerType
import com.example.model.MotionLayer
import com.example.model.Project
import com.example.model.ShapeType

object XmlProjectSerializer {

    fun serialize(project: Project): String {
        val sb = StringBuilder()
        val bgHex = String.format("#%08X", project.backgroundColor)

        sb.append("<?xml version=\"1.0\" encoding=\"utf-8\"?>\n")
        sb.append("<scene ")
        sb.append("name=\"${escapeXml(project.name)}\" ")
        sb.append("width=\"${project.width}\" ")
        sb.append("height=\"${project.height}\" ")
        sb.append("fps=\"${project.fps}\" ")
        sb.append("totalTime=\"${project.durationMs}\" ")
        sb.append("bgcolor=\"$bgHex\">\n")

        for (layer in project.layers) {
            serializeLayer(sb, layer)
        }

        // Re-emit any top-level unsupported nodes preserved from import
        for (node in project.unsupportedNodes) {
            sb.append("  <!-- Preserved Alight Motion node -->\n")
            sb.append("  <${node.tagName}")
            for ((k, v) in node.attributes) {
                sb.append(" $k=\"${escapeXml(v)}\"")
            }
            sb.append("/>\n")
        }

        sb.append("</scene>\n")
        return sb.toString()
    }

    private fun serializeLayer(sb: StringBuilder, layer: MotionLayer) {
        val tagName = when (layer.type) {
            LayerType.SHAPE -> "shape"
            LayerType.TEXT -> "text"
            LayerType.IMAGE -> "media"
            LayerType.VIDEO -> "video"
            LayerType.AUDIO -> "audio"
        }

        sb.append("  <$tagName ")
        sb.append("name=\"${escapeXml(layer.name)}\" ")
        sb.append("startTime=\"${layer.startTimeMs}\" ")
        sb.append("endTime=\"${layer.endTimeMs}\"")

        when (layer.type) {
            LayerType.SHAPE -> {
                sb.append(" type=\"${layer.shapeType.name.lowercase()}\"")
                sb.append(" width=\"${layer.width}\"")
                sb.append(" height=\"${layer.height}\"")
                sb.append(" cornerRadius=\"${layer.cornerRadius}\"")
            }
            LayerType.TEXT -> {
                sb.append(" text=\"${escapeXml(layer.text)}\"")
                sb.append(" size=\"${layer.textSize}\"")
                sb.append(" color=\"${String.format("#%08X", layer.textColor)}\"")
            }
            LayerType.IMAGE, LayerType.VIDEO -> {
                layer.mediaUri?.let { sb.append(" src=\"${escapeXml(it)}\"") }
            }
            LayerType.AUDIO -> {
                layer.mediaUri?.let { sb.append(" src=\"${escapeXml(it)}\"") }
                sb.append(" volume=\"${layer.audioVolume}\"")
            }
        }

        // Custom attributes from original XML
        for ((k, v) in layer.customXmlAttributes) {
            if (!k.startsWith("kf_")) {
                sb.append(" $k=\"${escapeXml(v)}\"")
            }
        }
        sb.append(">\n")

        // Transform block
        sb.append("    <transform>\n")
        // Position
        sb.append("      <property name=\"position\">\n")
        if (layer.positionKeyframes.isEmpty()) {
            sb.append("        <keyframe time=\"0\" value=\"${layer.transform.positionX},${layer.transform.positionY}\"/>\n")
        } else {
            for (kf in layer.positionKeyframes) {
                val curveStr = "${kf.curve.x1},${kf.curve.y1},${kf.curve.x2},${kf.curve.y2}"
                sb.append("        <keyframe time=\"${kf.timeMs}\" value=\"${kf.value.x},${kf.value.y}\" curve=\"$curveStr\"/>\n")
            }
        }
        sb.append("      </property>\n")

        // Scale
        sb.append("      <property name=\"scale\">\n")
        if (layer.scaleKeyframes.isEmpty()) {
            sb.append("        <keyframe time=\"0\" value=\"${layer.transform.scaleX},${layer.transform.scaleY}\"/>\n")
        } else {
            for (kf in layer.scaleKeyframes) {
                val curveStr = "${kf.curve.x1},${kf.curve.y1},${kf.curve.x2},${kf.curve.y2}"
                sb.append("        <keyframe time=\"${kf.timeMs}\" value=\"${kf.value.x},${kf.value.y}\" curve=\"$curveStr\"/>\n")
            }
        }
        sb.append("      </property>\n")

        // Rotation
        sb.append("      <property name=\"rotation\">\n")
        if (layer.rotationKeyframes.isEmpty()) {
            sb.append("        <keyframe time=\"0\" value=\"${layer.transform.rotation}\"/>\n")
        } else {
            for (kf in layer.rotationKeyframes) {
                val curveStr = "${kf.curve.x1},${kf.curve.y1},${kf.curve.x2},${kf.curve.y2}"
                sb.append("        <keyframe time=\"${kf.timeMs}\" value=\"${kf.value}\" curve=\"$curveStr\"/>\n")
            }
        }
        sb.append("      </property>\n")

        // Opacity
        sb.append("      <property name=\"opacity\">\n")
        if (layer.opacityKeyframes.isEmpty()) {
            sb.append("        <keyframe time=\"0\" value=\"${layer.transform.opacity}\"/>\n")
        } else {
            for (kf in layer.opacityKeyframes) {
                val curveStr = "${kf.curve.x1},${kf.curve.y1},${kf.curve.x2},${kf.curve.y2}"
                sb.append("        <keyframe time=\"${kf.timeMs}\" value=\"${kf.value}\" curve=\"$curveStr\"/>\n")
            }
        }
        sb.append("      </property>\n")
        sb.append("    </transform>\n")

        // Fill & Stroke
        if (layer.type == LayerType.SHAPE) {
            sb.append("    <fill color=\"${String.format("#%08X", layer.fillColor)}\"/>\n")
            if (layer.strokeWidth > 0f) {
                sb.append("    <stroke color=\"${String.format("#%08X", layer.strokeColor)}\" width=\"${layer.strokeWidth}\"/>\n")
            }
        }

        // Effects
        for (eff in layer.effects) {
            sb.append("    <effect type=\"${eff.type.lowercase()}\" color=\"${String.format("#%08X", eff.color)}\"/>\n")
        }

        // Preserved layer children
        for (child in layer.customXmlChildren) {
            sb.append("    <${child.tagName}")
            for ((k, v) in child.attributes) {
                sb.append(" $k=\"${escapeXml(v)}\"")
            }
            sb.append("/>\n")
        }

        sb.append("  </$tagName>\n")
    }

    private fun escapeXml(input: String): String {
        return input.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
            .replace("'", "&apos;")
    }
}
