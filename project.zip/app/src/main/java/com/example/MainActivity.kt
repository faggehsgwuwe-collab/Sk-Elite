package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.lifecycleScope
import com.example.model.Project
import com.example.repository.ProjectRepository
import com.example.ui.editor.EditorScreen
import com.example.ui.home.HomeScreen
import com.example.ui.theme.MotionStudioTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private lateinit var projectRepository: ProjectRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        projectRepository = ProjectRepository(applicationContext)

        setContent {
            MotionStudioTheme {
                var currentProject by remember { mutableStateOf<Project?>(null) }

                AnimatedContent(
                    targetState = currentProject,
                    transitionSpec = { fadeIn() togetherWith fadeOut() },
                    label = "screen_transition",
                    modifier = Modifier.fillMaxSize()
                ) { project ->
                    if (project == null) {
                        HomeScreen(
                            repository = projectRepository,
                            onOpenProject = { opened ->
                                currentProject = opened
                            },
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        EditorScreen(
                            initialProject = project,
                            onBack = { currentProject = null },
                            onSaveProject = { updated ->
                                currentProject = updated
                                lifecycleScope.launch {
                                    projectRepository.saveProject(updated)
                                }
                            },
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
            }
        }
    }
}
