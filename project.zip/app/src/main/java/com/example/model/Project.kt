package com.example.model

import java.util.UUID

enum class ProjectAspectRatio(val label: String, val widthRatio: Int, val heightRatio: Int) {
    RATIO_9_16("9:16 (Story / Reel / Shorts)", 9, 16),
    RATIO_16_9("16:9 (Landscape)", 16, 9),
    RATIO_1_1("1:1 (Square)", 1, 1),
    RATIO_4_5("4:5 (Portrait)", 4, 5),
    RATIO_4_3("4:3 (Classic)", 4, 3);

    companion object {
        fun fromDimensions(w: Int, h: Int): ProjectAspectRatio {
            val ratio = w.toFloat() / h.toFloat()
            return when {
                ratio < 0.65f -> RATIO_9_16
                ratio in 0.75f..0.85f -> RATIO_4_5
                ratio in 0.95f..1.05f -> RATIO_1_1
                ratio in 1.25f..1.4f -> RATIO_4_3
                else -> RATIO_16_9
            }
        }
    }
}

data class Project(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Untitled Motion",
    val width: Int = 1080,
    val height: Int = 1920,
    val fps: Int = 30,
    val durationMs: Long = 5000L,
    val backgroundColor: Long = 0xFF12141C,
    val layers: List<MotionLayer> = emptyList(),
    val unsupportedNodes: List<UnsupportedXmlNode> = emptyList(),
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    val aspectRatio: ProjectAspectRatio
        get() = ProjectAspectRatio.fromDimensions(width, height)

    val totalFrames: Int
        get() = ((durationMs * fps) / 1000).toInt().coerceAtLeast(1)

    fun frameToMs(frame: Int): Long {
        return (frame * 1000L) / fps
    }

    fun msToFrame(ms: Long): Int {
        return ((ms * fps) / 1000).toInt()
    }
}
