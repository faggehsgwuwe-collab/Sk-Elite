package com.example.model

import kotlin.math.abs

data class KeyframeCurve(
    val name: String = "Linear",
    val x1: Float = 0.0f,
    val y1: Float = 0.0f,
    val x2: Float = 1.0f,
    val y2: Float = 1.0f
) {
    /**
     * Solves the cubic Bezier equation for time t to find progress x,
     * then calculates the corresponding y.
     */
    fun evaluate(t: Float): Float {
        val clampedT = t.coerceIn(0f, 1f)
        if (x1 == y1 && x2 == y2 && (x1 == 0f || x1 == 0.33f)) {
            // Effectively linear
            if (x1 == 0f && x2 == 1f) return clampedT
        }

        // Newton-Raphson iteration to solve for parametric u where B_x(u) == clampedT
        var u = clampedT
        for (i in 0 until 6) {
            val currentX = sampleCurveX(u) - clampedT
            if (abs(currentX) < 1e-4f) break
            val dX = sampleCurveDerivativeX(u)
            if (abs(dX) < 1e-5f) break
            u -= currentX / dX
        }
        u = u.coerceIn(0f, 1f)
        return sampleCurveY(u).coerceIn(0f, 1f)
    }

    private fun sampleCurveX(u: Float): Float {
        // (1-u)^3*0 + 3*(1-u)^2*u*x1 + 3*(1-u)*u^2*x2 + u^3*1
        val oneMinusU = 1f - u
        return 3f * oneMinusU * oneMinusU * u * x1 + 3f * oneMinusU * u * u * x2 + u * u * u
    }

    private fun sampleCurveDerivativeX(u: Float): Float {
        val oneMinusU = 1f - u
        return 3f * oneMinusU * oneMinusU * x1 + 6f * oneMinusU * u * (x2 - x1) + 3f * u * u * (1f - x2)
    }

    private fun sampleCurveY(u: Float): Float {
        val oneMinusU = 1f - u
        return 3f * oneMinusU * oneMinusU * u * y1 + 3f * oneMinusU * u * u * y2 + u * u * u
    }

    companion object {
        val LINEAR = KeyframeCurve("Linear", 0.0f, 0.0f, 1.0f, 1.0f)
        val EASE_IN = KeyframeCurve("Ease In", 0.42f, 0.0f, 1.0f, 1.0f)
        val EASE_OUT = KeyframeCurve("Ease Out", 0.0f, 0.0f, 0.58f, 1.0f)
        val EASE_IN_OUT = KeyframeCurve("Ease In Out", 0.42f, 0.0f, 0.58f, 1.0f)
        val BOUNCE_IN = KeyframeCurve("Alight Smooth", 0.25f, 0.1f, 0.25f, 1.0f)
        val SNAP = KeyframeCurve("Sharp Snap", 0.05f, 0.9f, 0.2f, 1.0f)

        val ALL_PRESETS = listOf(LINEAR, EASE_IN, EASE_OUT, EASE_IN_OUT, BOUNCE_IN, SNAP)
    }
}

data class Point2D(val x: Float, val y: Float)

data class Keyframe<T>(
    val timeMs: Long,
    val value: T,
    val curve: KeyframeCurve = KeyframeCurve.EASE_IN_OUT
)
