package com.example.model

data class UnsupportedXmlNode(
    val tagName: String,
    val attributes: Map<String, String> = emptyMap(),
    val rawXml: String = "",
    val reason: String = "Unsupported effect or element in current mobile engine version"
)
