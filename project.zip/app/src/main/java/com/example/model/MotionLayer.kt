package com.example.model

import java.util.UUID

enum class LayerType {
    SHAPE,
    TEXT,
    IMAGE,
    VIDEO,
    AUDIO
}

enum class ShapeType {
    RECTANGLE,
    ROUNDED_RECT,
    CIRCLE,
    STAR,
    TRIANGLE,
    HEART
}

data class LayerTransform(
    val positionX: Float = 540f,
    val positionY: Float = 960f,
    val scaleX: Float = 1.0f,
    val scaleY: Float = 1.0f,
    val rotation: Float = 0.0f, // degrees
    val opacity: Float = 1.0f,   // 0.0 to 1.0
    val anchorX: Float = 0.5f,
    val anchorY: Float = 0.5f
)

data class LayerEffect(
    val id: String = UUID.randomUUID().toString(),
    val type: String, // "GLOW", "STROKE", "SHADOW", "BLUR", "TINT", "WAVE_WARP"
    val isEnabled: Boolean = true,
    val parameters: Map<String, Float> = emptyMap(),
    val color: Long = 0xFF00E5FF
)

data class MotionLayer(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val type: LayerType,
    val startTimeMs: Long = 0L,
    val endTimeMs: Long = 5000L,
    val isVisible: Boolean = true,
    val isLocked: Boolean = false,
    val blendMode: String = "NORMAL",

    // Base Transform
    val transform: LayerTransform = LayerTransform(),

    // Keyframe Tracks
    val positionKeyframes: List<Keyframe<Point2D>> = emptyList(),
    val scaleKeyframes: List<Keyframe<Point2D>> = emptyList(),
    val rotationKeyframes: List<Keyframe<Float>> = emptyList(),
    val opacityKeyframes: List<Keyframe<Float>> = emptyList(),

    // Shape-specific
    val shapeType: ShapeType = ShapeType.RECTANGLE,
    val width: Float = 400f,
    val height: Float = 300f,
    val fillColor: Long = 0xFF00E5FF,
    val strokeColor: Long = 0xFFFFFFFF,
    val strokeWidth: Float = 0f,
    val cornerRadius: Float = 24f,

    // Text-specific
    val text: String = "Motion Text",
    val textSize: Float = 64f,
    val textColor: Long = 0xFFFFFFFF,
    val textAlign: String = "CENTER",
    val letterSpacing: Float = 0f,
    val isBold: Boolean = true,

    // Media-specific (Image / Video / Audio)
    val mediaUri: String? = null,
    val mediaDurationMs: Long = 0L,
    val audioVolume: Float = 1.0f,

    // Effects
    val effects: List<LayerEffect> = emptyList(),

    // Preserved XML tags and attributes
    val customXmlAttributes: Map<String, String> = emptyMap(),
    val customXmlChildren: List<UnsupportedXmlNode> = emptyList()
) {
    fun hasKeyframes(): Boolean {
        return positionKeyframes.isNotEmpty() ||
                scaleKeyframes.isNotEmpty() ||
                rotationKeyframes.isNotEmpty() ||
                opacityKeyframes.isNotEmpty()
    }
}
