package com.example.repository

import android.content.Context
import android.net.Uri
import com.example.model.*
import com.example.parser.XmlProjectParser
import com.example.parser.XmlProjectSerializer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

class ProjectRepository(private val context: Context) {

    private val projectsDir: File
        get() = File(context.filesDir, "saved_projects").apply { if (!exists()) mkdirs() }

    suspend fun getAllProjects(): List<Project> = withContext(Dispatchers.IO) {
        val files = projectsDir.listFiles { _, name -> name.endsWith(".xml") || name.endsWith(".json") }
        val loaded = files?.mapNotNull { file ->
            try {
                if (file.name.endsWith(".xml")) {
                    val content = file.readText()
                    XmlProjectParser.parse(content).project.copy(id = file.nameWithoutExtension)
                } else {
                    parseProjectJson(file.readText())
                }
            } catch (e: Exception) {
                null
            }
        } ?: emptyList()

        if (loaded.isEmpty()) {
            // Seed sample projects
            val samples = getSampleProjects()
            samples.forEach { saveProject(it) }
            samples
        } else {
            loaded.sortedByDescending { it.updatedAt }
        }
    }

    suspend fun saveProject(project: Project): Unit = withContext(Dispatchers.IO) {
        val file = File(projectsDir, "${project.id}.xml")
        val xml = XmlProjectSerializer.serialize(project)
        file.writeText(xml)
    }

    suspend fun deleteProject(projectId: String): Boolean = withContext(Dispatchers.IO) {
        val xmlFile = File(projectsDir, "$projectId.xml")
        val jsonFile = File(projectsDir, "$projectId.json")
        xmlFile.delete() || jsonFile.delete()
    }

    suspend fun importProjectFromUri(uri: Uri): Pair<Project, List<String>> = withContext(Dispatchers.IO) {
        val content = context.contentResolver.openInputStream(uri)?.use { stream ->
            stream.bufferedReader().readText()
        } ?: throw IllegalArgumentException("Could not read project file")

        val result = XmlProjectParser.parse(content)
        val project = result.project.copy(
            id = UUID.randomUUID().toString(),
            updatedAt = System.currentTimeMillis()
        )
        saveProject(project)
        Pair(project, result.warnings)
    }

    suspend fun importProjectFromXmlString(xmlContent: String): Pair<Project, List<String>> = withContext(Dispatchers.IO) {
        val result = XmlProjectParser.parse(xmlContent)
        val project = result.project.copy(
            id = UUID.randomUUID().toString(),
            updatedAt = System.currentTimeMillis()
        )
        saveProject(project)
        Pair(project, result.warnings)
    }

    fun getSampleXmlCode(): String {
        return """
<?xml version="1.0" encoding="utf-8"?>
<!-- SK MUZAMMEL Motion Studio / Alight Motion XML Project Demo -->
<scene name="SK MUZAMMEL Kinetic Intro" width="1080" height="1920" fps="30" totalTime="5000" bgcolor="#0D0F17">
  <!-- Glowing Neon Backdrop Shape -->
  <shape name="Neon Glow Aura" type="circle" startTime="0" endTime="5000" width="800" height="800">
    <transform>
      <property name="position">
        <keyframe time="0" value="540,960" curve="0.25,0.1,0.25,1.0"/>
        <keyframe time="2500" value="540,900" curve="0.25,0.1,0.25,1.0"/>
        <keyframe time="5000" value="540,960"/>
      </property>
      <property name="scale">
        <keyframe time="0" value="0.7,0.7" curve="0.42,0.0,0.58,1.0"/>
        <keyframe time="2500" value="1.25,1.25" curve="0.42,0.0,0.58,1.0"/>
        <keyframe time="5000" value="0.7,0.7"/>
      </property>
      <property name="opacity">
        <keyframe time="0" value="0.3"/>
        <keyframe time="2500" value="0.8"/>
        <keyframe time="5000" value="0.3"/>
      </property>
    </transform>
    <fill color="#FF7C4DFF"/>
    <effect type="glow" color="#FF00E5FF"/>
  </shape>

  <!-- Rotating Diamond Accent -->
  <shape name="Cyber Diamond" type="rect" startTime="500" endTime="5000" width="320" height="320" cornerRadius="48">
    <transform>
      <property name="position">
        <keyframe time="500" value="540,960"/>
      </property>
      <property name="rotation">
        <keyframe time="500" value="0" curve="0.25,0.1,0.25,1.0"/>
        <keyframe time="2500" value="180" curve="0.25,0.1,0.25,1.0"/>
        <keyframe time="5000" value="360"/>
      </property>
      <property name="scale">
        <keyframe time="500" value="0.2,0.2" curve="0.05,0.9,0.2,1.0"/>
        <keyframe time="1500" value="1.0,1.0"/>
      </property>
    </transform>
    <fill color="#FF1A1E2E"/>
    <stroke color="#FF00E5FF" width="8"/>
    <effect type="glow" color="#FF00E5FF"/>
  </shape>

  <!-- Kinetic Title Text -->
  <text name="Main Title" text="SK MUZAMMEL" size="84" color="#FFFFFFFF" startTime="1000" endTime="5000">
    <transform>
      <property name="position">
        <keyframe time="1000" value="540,1200" curve="0.05,0.9,0.2,1.0"/>
        <keyframe time="2000" value="540,920"/>
      </property>
      <property name="scale">
        <keyframe time="1000" value="0.5,0.5" curve="0.05,0.9,0.2,1.0"/>
        <keyframe time="2000" value="1.05,1.05"/>
        <keyframe time="2400" value="1.0,1.0"/>
      </property>
      <property name="opacity">
        <keyframe time="1000" value="0.0"/>
        <keyframe time="1600" value="1.0"/>
      </property>
    </transform>
    <effect type="glow" color="#FF00E5FF"/>
  </text>

  <!-- Subtitle Text -->
  <text name="Subtitle" text="MOTION STUDIO" size="44" color="#FF00E676" startTime="1500" endTime="5000">
    <transform>
      <property name="position">
        <keyframe time="1500" value="540,1050" curve="0.0,0.0,0.58,1.0"/>
        <keyframe time="2500" value="540,1020"/>
      </property>
      <property name="opacity">
        <keyframe time="1500" value="0.0"/>
        <keyframe time="2200" value="1.0"/>
      </property>
    </transform>
  </text>

  <!-- Unsupported Alight Motion Camera Tag (Preserved for compatibility) -->
  <camera3d fov="45" target="540,960,0" focalLength="50" depthOfField="true" />
</scene>
        """.trimIndent()
    }

    fun getSampleProjects(): List<Project> {
        val sample1 = XmlProjectParser.parse(getSampleXmlCode()).project.copy(
            id = "sample_kinetic_intro",
            name = "SK MUZAMMEL Kinetic Intro"
        )

        val sample2 = Project(
            id = "sample_cyber_beats",
            name = "Neon Glitch Reel (9:16)",
            width = 1080,
            height = 1920,
            fps = 30,
            durationMs = 4000L,
            backgroundColor = 0xFF0A0C14,
            layers = listOf(
                MotionLayer(
                    id = "layer_glow_bg",
                    name = "Pulsing Core",
                    type = LayerType.SHAPE,
                    shapeType = ShapeType.ROUNDED_RECT,
                    startTimeMs = 0L,
                    endTimeMs = 4000L,
                    width = 600f,
                    height = 600f,
                    fillColor = 0xFF00E5FF,
                    cornerRadius = 80f,
                    transform = LayerTransform(positionX = 540f, positionY = 960f, scaleX = 1f, scaleY = 1f),
                    scaleKeyframes = listOf(
                        Keyframe(0L, Point2D(0.8f, 0.8f), KeyframeCurve.SNAP),
                        Keyframe(1000L, Point2D(1.15f, 1.15f), KeyframeCurve.SNAP),
                        Keyframe(2000L, Point2D(0.9f, 0.9f), KeyframeCurve.SNAP),
                        Keyframe(3000L, Point2D(1.2f, 1.2f), KeyframeCurve.SNAP),
                        Keyframe(4000L, Point2D(0.8f, 0.8f), KeyframeCurve.SNAP)
                    ),
                    rotationKeyframes = listOf(
                        Keyframe(0L, 0f, KeyframeCurve.EASE_IN_OUT),
                        Keyframe(2000L, 180f, KeyframeCurve.EASE_IN_OUT),
                        Keyframe(4000L, 360f, KeyframeCurve.EASE_IN_OUT)
                    ),
                    effects = listOf(LayerEffect(type = "GLOW", color = 0xFF00E5FF))
                ),
                MotionLayer(
                    id = "layer_star_accent",
                    name = "Star Burst",
                    type = LayerType.SHAPE,
                    shapeType = ShapeType.STAR,
                    startTimeMs = 500L,
                    endTimeMs = 3500L,
                    width = 280f,
                    height = 280f,
                    fillColor = 0xFFFFEA00,
                    strokeColor = 0xFFFFFFFF,
                    strokeWidth = 4f,
                    transform = LayerTransform(positionX = 540f, positionY = 960f),
                    rotationKeyframes = listOf(
                        Keyframe(500L, 0f, KeyframeCurve.LINEAR),
                        Keyframe(3500L, 720f, KeyframeCurve.LINEAR)
                    ),
                    opacityKeyframes = listOf(
                        Keyframe(500L, 0f, KeyframeCurve.EASE_OUT),
                        Keyframe(1000L, 1f, KeyframeCurve.EASE_OUT),
                        Keyframe(3000L, 1f, KeyframeCurve.EASE_IN),
                        Keyframe(3500L, 0f, KeyframeCurve.EASE_IN)
                    )
                ),
                MotionLayer(
                    id = "layer_text_title",
                    name = "Glitch Text",
                    type = LayerType.TEXT,
                    text = "NEXT LEVEL MOTION",
                    textSize = 72f,
                    textColor = 0xFFFFFFFF,
                    startTimeMs = 800L,
                    endTimeMs = 4000L,
                    transform = LayerTransform(positionX = 540f, positionY = 960f),
                    positionKeyframes = listOf(
                        Keyframe(800L, Point2D(540f, 1300f), KeyframeCurve.BOUNCE_IN),
                        Keyframe(1600L, Point2D(540f, 960f), KeyframeCurve.BOUNCE_IN)
                    ),
                    effects = listOf(LayerEffect(type = "GLOW", color = 0xFFFF4081))
                )
            )
        )

        return listOf(sample1, sample2)
    }

    private fun parseProjectJson(jsonStr: String): Project {
        val root = JSONObject(jsonStr)
        return Project(
            id = root.optString("id", UUID.randomUUID().toString()),
            name = root.optString("name", "Untitled Project"),
            width = root.optInt("width", 1080),
            height = root.optInt("height", 1920),
            fps = root.optInt("fps", 30),
            durationMs = root.optLong("durationMs", 5000L),
            backgroundColor = root.optLong("backgroundColor", 0xFF12141CL),
            createdAt = root.optLong("createdAt", System.currentTimeMillis()),
            updatedAt = root.optLong("updatedAt", System.currentTimeMillis())
        )
    }
}
