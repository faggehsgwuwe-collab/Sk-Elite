package com.example.engine

import android.content.Context
import android.graphics.*
import com.example.model.LayerType
import com.example.model.MotionLayer
import com.example.model.Project
import com.example.model.ShapeType
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

object CanvasFrameRenderer {

    fun renderFrame(
        canvas: Canvas,
        project: Project,
        timeMs: Long,
        renderWidth: Int,
        renderHeight: Int,
        loadedBitmaps: Map<String, Bitmap> = emptyMap()
    ) {
        // Draw background
        canvas.drawColor(project.backgroundColor.toInt())

        val scaleFactorX = renderWidth.toFloat() / project.width.toFloat()
        val scaleFactorY = renderHeight.toFloat() / project.height.toFloat()

        canvas.save()
        canvas.scale(scaleFactorX, scaleFactorY)

        val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
        }
        val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
        }
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textAlign = Paint.Align.CENTER
        }

        for (layer in project.layers) {
            val state = TimelineInterpolator.evaluate(layer, timeMs)
            if (!state.isVisibleAtTime || state.opacity <= 0.001f) continue

            canvas.save()

            // Apply transform: Position, Rotation, Scale
            canvas.translate(state.positionX, state.positionY)
            canvas.rotate(state.rotation)
            canvas.scale(state.scaleX, state.scaleY)

            val alphaInt = (state.opacity * 255f).toInt().coerceIn(0, 255)

            when (layer.type) {
                LayerType.SHAPE -> {
                    renderShape(canvas, layer, fillPaint, strokePaint, alphaInt)
                }
                LayerType.TEXT -> {
                    renderText(canvas, layer, textPaint, alphaInt)
                }
                LayerType.IMAGE -> {
                    renderImage(canvas, layer, loadedBitmaps, fillPaint, alphaInt)
                }
                LayerType.VIDEO -> {
                    renderVideoPlaceholder(canvas, layer, fillPaint, strokePaint, alphaInt, timeMs)
                }
                LayerType.AUDIO -> {
                    // Audio does not draw on video canvas
                }
            }

            canvas.restore()
        }

        canvas.restore()
    }

    private fun renderShape(
        canvas: Canvas,
        layer: MotionLayer,
        fillPaint: Paint,
        strokePaint: Paint,
        alphaInt: Int
    ) {
        val w = layer.width
        val h = layer.height
        val left = -w / 2f
        val top = -h / 2f
        val right = w / 2f
        val bottom = h / 2f
        val rectF = RectF(left, top, right, bottom)

        fillPaint.color = layer.fillColor.toInt()
        fillPaint.alpha = (fillPaint.alpha * (alphaInt / 255f)).toInt().coerceIn(0, 255)

        // Check for glow effect
        val glowEffect = layer.effects.firstOrNull { it.type == "GLOW" && it.isEnabled }
        if (glowEffect != null) {
            fillPaint.setShadowLayer(30f, 0f, 0f, glowEffect.color.toInt())
        } else {
            fillPaint.clearShadowLayer()
        }

        when (layer.shapeType) {
            ShapeType.RECTANGLE -> {
                canvas.drawRect(rectF, fillPaint)
            }
            ShapeType.ROUNDED_RECT -> {
                val cr = layer.cornerRadius.coerceAtMost(min(w, h) / 2f)
                canvas.drawRoundRect(rectF, cr, cr, fillPaint)
            }
            ShapeType.CIRCLE -> {
                val radius = min(w, h) / 2f
                canvas.drawCircle(0f, 0f, radius, fillPaint)
            }
            ShapeType.STAR -> {
                drawStar(canvas, 0f, 0f, min(w, h) / 2f, min(w, h) / 4f, 5, fillPaint)
            }
            ShapeType.TRIANGLE -> {
                val path = Path().apply {
                    moveTo(0f, top)
                    lineTo(right, bottom)
                    lineTo(left, bottom)
                    close()
                }
                canvas.drawPath(path, fillPaint)
            }
            ShapeType.HEART -> {
                drawHeart(canvas, rectF, fillPaint)
            }
        }

        // Draw stroke if specified
        if (layer.strokeWidth > 0f) {
            strokePaint.color = layer.strokeColor.toInt()
            strokePaint.strokeWidth = layer.strokeWidth
            strokePaint.alpha = (strokePaint.alpha * (alphaInt / 255f)).toInt().coerceIn(0, 255)

            when (layer.shapeType) {
                ShapeType.RECTANGLE -> canvas.drawRect(rectF, strokePaint)
                ShapeType.ROUNDED_RECT -> canvas.drawRoundRect(rectF, layer.cornerRadius, layer.cornerRadius, strokePaint)
                ShapeType.CIRCLE -> canvas.drawCircle(0f, 0f, min(w, h) / 2f, strokePaint)
                ShapeType.TRIANGLE -> {
                    val path = Path().apply {
                        moveTo(0f, top)
                        lineTo(right, bottom)
                        lineTo(left, bottom)
                        close()
                    }
                    canvas.drawPath(path, strokePaint)
                }
                else -> { /* stroke for star/heart */ }
            }
        }
    }

    private fun renderText(
        canvas: Canvas,
        layer: MotionLayer,
        textPaint: Paint,
        alphaInt: Int
    ) {
        textPaint.color = layer.textColor.toInt()
        textPaint.alpha = (textPaint.alpha * (alphaInt / 255f)).toInt().coerceIn(0, 255)
        textPaint.textSize = layer.textSize
        textPaint.typeface = if (layer.isBold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT

        // Glow
        val glowEffect = layer.effects.firstOrNull { it.type == "GLOW" && it.isEnabled }
        if (glowEffect != null) {
            textPaint.setShadowLayer(25f, 0f, 0f, glowEffect.color.toInt())
        } else {
            textPaint.clearShadowLayer()
        }

        val fontMetrics = textPaint.fontMetrics
        val baseline = -(fontMetrics.ascent + fontMetrics.descent) / 2f
        canvas.drawText(layer.text, 0f, baseline, textPaint)
    }

    private fun renderImage(
        canvas: Canvas,
        layer: MotionLayer,
        loadedBitmaps: Map<String, Bitmap>,
        paint: Paint,
        alphaInt: Int
    ) {
        val w = layer.width
        val h = layer.height
        val rectF = RectF(-w / 2f, -h / 2f, w / 2f, h / 2f)

        val bmp = layer.mediaUri?.let { loadedBitmaps[it] }
        if (bmp != null) {
            paint.alpha = alphaInt
            canvas.drawBitmap(bmp, null, rectF, paint)
        } else {
            // Stylized placeholder pattern
            paint.color = 0xFF2A2E42.toInt()
            paint.alpha = alphaInt
            canvas.drawRoundRect(rectF, 20f, 20f, paint)

            paint.color = 0xFF00E5FF.toInt()
            paint.alpha = (alphaInt * 0.8f).toInt()
            paint.textSize = 28f
            paint.textAlign = Paint.Align.CENTER
            canvas.drawText(layer.name, 0f, 0f, paint)
        }
    }

    private fun renderVideoPlaceholder(
        canvas: Canvas,
        layer: MotionLayer,
        fillPaint: Paint,
        strokePaint: Paint,
        alphaInt: Int,
        timeMs: Long
    ) {
        val w = layer.width
        val h = layer.height
        val rectF = RectF(-w / 2f, -h / 2f, w / 2f, h / 2f)

        // Animated neon gradient effect
        val shift = (timeMs % 2000L).toFloat() / 2000f * w
        val shader = LinearGradient(
            -w / 2f + shift, -h / 2f, w / 2f + shift, h / 2f,
            intArrayOf(0xFF7C4DFF.toInt(), 0xFF00E5FF.toInt(), 0xFF00E676.toInt()),
            null,
            Shader.TileMode.MIRROR
        )
        fillPaint.shader = shader
        fillPaint.alpha = alphaInt
        canvas.drawRoundRect(rectF, 24f, 24f, fillPaint)
        fillPaint.shader = null

        strokePaint.color = 0xFFFFFFFF.toInt()
        strokePaint.strokeWidth = 3f
        strokePaint.alpha = (alphaInt * 0.7f).toInt()
        canvas.drawRoundRect(rectF, 24f, 24f, strokePaint)
    }

    private fun drawStar(
        canvas: Canvas,
        cx: Float,
        cy: Float,
        outerRadius: Float,
        innerRadius: Float,
        points: Int,
        paint: Paint
    ) {
        val path = Path()
        val step = Math.PI / points
        var angle = -Math.PI / 2.0
        path.moveTo((cx + outerRadius * cos(angle)).toFloat(), (cy + outerRadius * sin(angle)).toFloat())

        for (i in 0 until points * 2) {
            angle += step
            val r = if (i % 2 == 0) innerRadius else outerRadius
            path.lineTo((cx + r * cos(angle)).toFloat(), (cy + r * sin(angle)).toFloat())
        }
        path.close()
        canvas.drawPath(path, paint)
    }

    private fun drawHeart(canvas: Canvas, rect: RectF, paint: Paint) {
        val path = Path()
        val w = rect.width()
        val h = rect.height()
        path.moveTo(0f, -h * 0.2f)
        path.cubicTo(-w * 0.5f, -h * 0.6f, -w * 0.5f, 0f, 0f, h * 0.45f)
        path.cubicTo(w * 0.5f, 0f, w * 0.5f, -h * 0.6f, 0f, -h * 0.2f)
        path.close()
        canvas.drawPath(path, paint)
    }
}
