package com.example.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.util.Log
import com.example.model.Project
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean

data class ExportProgress(
    val currentFrame: Int,
    val totalFrames: Int,
    val percentage: Int,
    val message: String
)

object VideoExportEngine {
    private const val TAG = "VideoExportEngine"

    suspend fun exportVideo(
        context: Context,
        project: Project,
        targetWidth: Int,
        targetHeight: Int,
        fps: Int,
        isCancelled: AtomicBoolean,
        onProgress: (ExportProgress) -> Unit
    ): Result<File> = withContext(Dispatchers.Default) {
        var codec: MediaCodec? = null
        var muxer: MediaMuxer? = null
        var tempFile: File? = null

        try {
            // Width and height must be even numbers for H.264
            val width = if (targetWidth % 2 != 0) targetWidth - 1 else targetWidth
            val height = if (targetHeight % 2 != 0) targetHeight - 1 else targetHeight

            val exportDir = File(context.getExternalFilesDir(null) ?: context.filesDir, "exports")
            if (!exportDir.exists()) exportDir.mkdirs()

            val sanitizedName = project.name.replace("[^a-zA-Z0-9_-]".toRegex(), "_")
            tempFile = File(exportDir, "${sanitizedName}_${System.currentTimeMillis()}.mp4")

            val totalFrames = ((project.durationMs * fps) / 1000).toInt().coerceAtLeast(1)

            onProgress(ExportProgress(0, totalFrames, 0, "Initializing hardware video encoder..."))

            // Setup MediaCodec format
            val mimeType = MediaFormat.MIMETYPE_VIDEO_AVC
            val format = MediaFormat.createVideoFormat(mimeType, width, height).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420SemiPlanar)
                setInteger(MediaFormat.KEY_BIT_RATE, (width * height * 4).coerceIn(1_500_000, 15_000_000))
                setInteger(MediaFormat.KEY_FRAME_RATE, fps)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            }

            codec = MediaCodec.createEncoderByType(mimeType)
            codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            codec.start()

            muxer = MediaMuxer(tempFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            var videoTrackIndex = -1
            var muxerStarted = false

            val frameBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val renderCanvas = Canvas(frameBitmap)
            val argbPixels = IntArray(width * height)
            val yuvBytes = ByteArray(width * height * 3 / 2)
            val bufferInfo = MediaCodec.BufferInfo()

            val frameDurationUs = 1_000_000L / fps

            for (frame in 0 until totalFrames) {
                if (isCancelled.get()) {
                    throw InterruptedException("Export cancelled by user")
                }

                val timeMs = (frame * 1000L) / fps

                // Render current frame onto bitmap
                CanvasFrameRenderer.renderFrame(
                    canvas = renderCanvas,
                    project = project,
                    timeMs = timeMs,
                    renderWidth = width,
                    renderHeight = height
                )

                // Convert ARGB to YUV420 (NV12 / Semi-planar)
                frameBitmap.getPixels(argbPixels, 0, width, 0, 0, width, height)
                encodeYUV420SP(yuvBytes, argbPixels, width, height)

                // Feed frame into MediaCodec
                var inputFed = false
                while (!inputFed && !isCancelled.get()) {
                    val inputBufferIndex = codec.dequeueInputBuffer(10_000)
                    if (inputBufferIndex >= 0) {
                        val inputBuffer: ByteBuffer? = codec.getInputBuffer(inputBufferIndex)
                        if (inputBuffer != null) {
                            inputBuffer.clear()
                            inputBuffer.put(yuvBytes)
                            val presentationTimeUs = frame * frameDurationUs
                            val flags = if (frame == totalFrames - 1) MediaCodec.BUFFER_FLAG_END_OF_STREAM else 0
                            codec.queueInputBuffer(inputBufferIndex, 0, yuvBytes.size, presentationTimeUs, flags)
                            inputFed = true
                        }
                    }
                    drainEncoder(codec, muxer, bufferInfo, { videoTrackIndex = it }, { muxerStarted = it }, false)
                }

                val percent = (((frame + 1).toFloat() / totalFrames) * 100).toInt()
                onProgress(ExportProgress(frame + 1, totalFrames, percent, "Rendering frame ${frame + 1}/$totalFrames ($percent%)"))
            }

            // Drain remaining frames until EOS
            while (!isCancelled.get()) {
                val done = drainEncoder(codec, muxer, bufferInfo, { videoTrackIndex = it }, { muxerStarted = it }, true)
                if (done) break
            }

            frameBitmap.recycle()

            onProgress(ExportProgress(totalFrames, totalFrames, 100, "Finalizing MP4 video container..."))
            Result.success(tempFile)
        } catch (e: Exception) {
            Log.e(TAG, "Video export failed", e)
            tempFile?.delete()
            Result.failure(e)
        } finally {
            try {
                codec?.stop()
                codec?.release()
            } catch (ignored: Exception) {}
            try {
                muxer?.stop()
                muxer?.release()
            } catch (ignored: Exception) {}
        }
    }

    private fun drainEncoder(
        codec: MediaCodec,
        muxer: MediaMuxer?,
        bufferInfo: MediaCodec.BufferInfo,
        setTrackIndex: (Int) -> Unit,
        setMuxerStarted: (Boolean) -> Unit,
        endOfStream: Boolean
    ): Boolean {
        var isEosReached = false
        val timeout = if (endOfStream) 10_000L else 0L

        while (true) {
            val outputBufferIndex = codec.dequeueOutputBuffer(bufferInfo, timeout)
            if (outputBufferIndex == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (!endOfStream) break else continue
            } else if (outputBufferIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                if (muxer != null) {
                    val newFormat = codec.outputFormat
                    val trackIndex = muxer.addTrack(newFormat)
                    setTrackIndex(trackIndex)
                    muxer.start()
                    setMuxerStarted(true)
                }
            } else if (outputBufferIndex >= 0) {
                val outputBuffer = codec.getOutputBuffer(outputBufferIndex)
                if (outputBuffer != null && bufferInfo.size > 0) {
                    outputBuffer.position(bufferInfo.offset)
                    outputBuffer.limit(bufferInfo.offset + bufferInfo.size)
                    try {
                        muxer?.writeSampleData(0, outputBuffer, bufferInfo)
                    } catch (e: Exception) {
                        Log.w(TAG, "Write sample failed: ${e.message}")
                    }
                }
                codec.releaseOutputBuffer(outputBufferIndex, false)

                if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                    isEosReached = true
                    break
                }
            }
        }
        return isEosReached
    }

    private fun encodeYUV420SP(yuv420sp: ByteArray, argb: IntArray, width: Int, height: Int) {
        val frameSize = width * height
        var yIndex = 0
        var uvIndex = frameSize
        var index = 0

        for (j in 0 until height) {
            for (i in 0 until width) {
                val c = argb[index++]
                val r = (c shr 16) and 0xff
                val g = (c shr 8) and 0xff
                val b = c and 0xff

                val y = ((66 * r + 129 * g + 25 * b + 128) shr 8) + 16
                val u = ((-38 * r - 74 * g + 112 * b + 128) shr 8) + 128
                val v = ((112 * r - 94 * g - 18 * b + 128) shr 8) + 128

                yuv420sp[yIndex++] = (if (y < 16) 16 else if (y > 235) 235 else y).toByte()

                if (j % 2 == 0 && i % 2 == 0) {
                    yuv420sp[uvIndex++] = (if (u < 16) 16 else if (u > 240) 240 else u).toByte()
                    yuv420sp[uvIndex++] = (if (v < 16) 16 else if (v > 240) 240 else v).toByte()
                }
            }
        }
    }
}
