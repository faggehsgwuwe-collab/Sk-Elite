package com.example.engine

import com.example.model.Keyframe
import com.example.model.LayerTransform
import com.example.model.MotionLayer
import com.example.model.Point2D

data class EvaluatedLayerState(
    val layer: MotionLayer,
    val isVisibleAtTime: Boolean,
    val positionX: Float,
    val positionY: Float,
    val scaleX: Float,
    val scaleY: Float,
    val rotation: Float,
    val opacity: Float
)

object TimelineInterpolator {

    fun evaluate(layer: MotionLayer, timeMs: Long): EvaluatedLayerState {
        val isWithinTime = layer.isVisible && timeMs in layer.startTimeMs..layer.endTimeMs
        if (!isWithinTime) {
            return EvaluatedLayerState(
                layer = layer,
                isVisibleAtTime = false,
                positionX = layer.transform.positionX,
                positionY = layer.transform.positionY,
                scaleX = layer.transform.scaleX,
                scaleY = layer.transform.scaleY,
                rotation = layer.transform.rotation,
                opacity = 0f
            )
        }

        val posX: Float
        val posY: Float
        if (layer.positionKeyframes.isEmpty()) {
            posX = layer.transform.positionX
            posY = layer.transform.positionY
        } else {
            val point = interpolatePoint(layer.positionKeyframes, timeMs, Point2D(layer.transform.positionX, layer.transform.positionY))
            posX = point.x
            posY = point.y
        }

        val scaleX: Float
        val scaleY: Float
        if (layer.scaleKeyframes.isEmpty()) {
            scaleX = layer.transform.scaleX
            scaleY = layer.transform.scaleY
        } else {
            val point = interpolatePoint(layer.scaleKeyframes, timeMs, Point2D(layer.transform.scaleX, layer.transform.scaleY))
            scaleX = point.x
            scaleY = point.y
        }

        val rotation = if (layer.rotationKeyframes.isEmpty()) {
            layer.transform.rotation
        } else {
            interpolateFloat(layer.rotationKeyframes, timeMs, layer.transform.rotation)
        }

        val opacity = if (layer.opacityKeyframes.isEmpty()) {
            layer.transform.opacity
        } else {
            interpolateFloat(layer.opacityKeyframes, timeMs, layer.transform.opacity)
        }.coerceIn(0f, 1f)

        return EvaluatedLayerState(
            layer = layer,
            isVisibleAtTime = true,
            positionX = posX,
            positionY = posY,
            scaleX = scaleX,
            scaleY = scaleY,
            rotation = rotation,
            opacity = opacity
        )
    }

    private fun interpolateFloat(
        keyframes: List<Keyframe<Float>>,
        timeMs: Long,
        defaultValue: Float
    ): Float {
        if (keyframes.isEmpty()) return defaultValue
        if (timeMs <= keyframes.first().timeMs) return keyframes.first().value
        if (timeMs >= keyframes.last().timeMs) return keyframes.last().value

        for (i in 0 until keyframes.size - 1) {
            val k1 = keyframes[i]
            val k2 = keyframes[i + 1]
            if (timeMs in k1.timeMs..k2.timeMs) {
                val span = (k2.timeMs - k1.timeMs).toFloat().coerceAtLeast(1f)
                val linearProgress = (timeMs - k1.timeMs).toFloat() / span
                val easedProgress = k1.curve.evaluate(linearProgress)
                return k1.value + (k2.value - k1.value) * easedProgress
            }
        }
        return defaultValue
    }

    private fun interpolatePoint(
        keyframes: List<Keyframe<Point2D>>,
        timeMs: Long,
        defaultValue: Point2D
    ): Point2D {
        if (keyframes.isEmpty()) return defaultValue
        if (timeMs <= keyframes.first().timeMs) return keyframes.first().value
        if (timeMs >= keyframes.last().timeMs) return keyframes.last().value

        for (i in 0 until keyframes.size - 1) {
            val k1 = keyframes[i]
            val k2 = keyframes[i + 1]
            if (timeMs in k1.timeMs..k2.timeMs) {
                val span = (k2.timeMs - k1.timeMs).toFloat().coerceAtLeast(1f)
                val linearProgress = (timeMs - k1.timeMs).toFloat() / span
                val easedProgress = k1.curve.evaluate(linearProgress)
                val x = k1.value.x + (k2.value.x - k1.value.x) * easedProgress
                val y = k1.value.y + (k2.value.y - k1.value.y) * easedProgress
                return Point2D(x, y)
            }
        }
        return defaultValue
    }
}
